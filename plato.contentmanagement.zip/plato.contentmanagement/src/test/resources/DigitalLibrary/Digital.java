package test;
import digitalLibrary.serviceImpl.CmDigitalLibraryCourseServiceImpl;
import digitalLibrary.entity.CmDigitalLibraryCourse;
import digitalLibrary.service.CmDigitalLibraryCourseService;
import digitalLibrary.dao.CmDigitalLibraryCourseDao;
import digitalLibrary.daoImpl.CmDigitalLibraryCourseDaoImpl;

import java.io.File;
import java.io.IOException;
import java.util.Set;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;


public class Digital {
	
	  public static void main(String[] args) {
		    Filename filename = new Filename(FPATH, '/', '.');
		    System.out.println("Extension = " + filename.extension());
		    System.out.println("Filename = " + filename.filename());
		    System.out.println("Path = " + filename.path());
		  }
	  	  class Filename{
		  private String fullPath;
		  private char pathSeparator, extensionSeparator;

		  public Filename(String str, char sep, char ext) {
		    fullPath = str;
		    pathSeparator = sep;
		    extensionSeparator = ext;
		  }

		  public String extension() {
		    int dot = fullPath.lastIndexOf(extensionSeparator);
		    return fullPath.substring(dot + 1);
		  }

		  public String filename() { // gets filename without extension
		    int dot = fullPath.lastIndexOf(extensionSeparator);
		    int sep = fullPath.lastIndexOf(pathSeparator);
		    return fullPath.substring(sep + 1, dot);
		  }

		  public String path() {
		    int sep = fullPath.lastIndexOf(pathSeparator);
		    return fullPath.substring(0, sep);
		  }
	  }
}
