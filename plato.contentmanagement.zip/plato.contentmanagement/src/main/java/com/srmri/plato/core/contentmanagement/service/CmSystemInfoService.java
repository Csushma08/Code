package com.srmri.plato.core.contentmanagement.service;

import java.util.List;

import com.srmri.plato.core.contentmanagement.entity.CmSystemInfo;


public interface CmSystemInfoService 
{
	
	boolean blAddSystemInfo(CmSystemInfo systemInfo);

	List<CmSystemInfo> blListAllSystemInfos();
	
	CmSystemInfo blGetSystemInfo(int systemInfoId);
	
	boolean blDeleteSystemInfo(CmSystemInfo systemInfoId);

}
