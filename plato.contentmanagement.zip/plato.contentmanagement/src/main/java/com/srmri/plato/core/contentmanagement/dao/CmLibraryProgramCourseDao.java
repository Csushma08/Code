package com.srmri.plato.core.contentmanagement.dao;

import java.util.List;

import com.srmri.plato.core.contentmanagement.entity.CmLibraryProgramCourse;

public interface CmLibraryProgramCourseDao 
{
	
	void dAddLibraryProgramCourseContent(CmLibraryProgramCourse libraryProgramCourse);

	List<CmLibraryProgramCourse> dListAllLibraryProgramCourseContents();
	
	CmLibraryProgramCourse dGetLibraryProgramCourseContent(long libraryProgramCourseId);
	
	void dDeleteLibraryProgramCourseContent(CmLibraryProgramCourse libraryProgramCourse);
	
	List<CmLibraryProgramCourse> dGetContentByTitle(String title);
	
	List<CmLibraryProgramCourse> dGetContentByAuthorName(String authors);
	
	List<CmLibraryProgramCourse> dGetContentByYearOfPublication(String yearofpublication);
	
	List<CmLibraryProgramCourse> dGetContentByPublisher(String publisher);

	List<CmLibraryProgramCourse> dGetContentByUploadedBy(long uploadedBy);

	void dSoftDeleteLibraryProgramCourseContent(CmLibraryProgramCourse libraryProgramCourse);
	
	void dRestoreLibraryProgramCourseContent(CmLibraryProgramCourse libraryProgramCourse);
	
	List<CmLibraryProgramCourse> dGetContentByProgramCourseMapId(long programCourseMapId);
	
	/* methods for fetching content by department, program and course Id's
	 * Integration
	 * Added Date: 6th June 2016
	 */
	List<CmLibraryProgramCourse> dGetContentByDeptId(Long departmentId);
	
	List<CmLibraryProgramCourse> dGetContentByDeptIdAndProgramId(Long departmentId, Long programId);
	
	List<CmLibraryProgramCourse> dGetContentByDeptIdProgramIdCourseId(Long departmentId, Long programId, Long courseId);
	
	List<CmLibraryProgramCourse> dGetContentByDeptIdProgramIdCourseIdContentType(Long departmentId, Long programId, Long courseId, Integer contentTypeId);
	
	List<CmLibraryProgramCourse> dGetContentByDeptIdAndContentType(Long departmentId, Integer contentTypeId);
	
	List<CmLibraryProgramCourse> dGetContentByDeptIdProgramIdContentType(Long departmentId, Long programId, Integer contentTypeId);
	
	List<CmLibraryProgramCourse> dGetContentByContentType(Integer contentType, Long programId);
	
	List<CmLibraryProgramCourse> dGetContentByContentTypeAndCourseId(Integer contentType, Long courseId);
	
	List<CmLibraryProgramCourse> dGetContentByCourseIdSort();
	
	List<CmLibraryProgramCourse> dGetContentByCourseId(Long courseId);
	
	List<CmLibraryProgramCourse> dGetContentByContentType(Integer contentType);
	
	/*
	 * methods for my content page
	 */
	
	List<CmLibraryProgramCourse> dGetContentByDeptIdAndUploadedBy(Long departmentId, Long uploadedBy);
	
	List<CmLibraryProgramCourse> dGetContentByDeptIdProgramIdUploadedBy(Long departmentId, Long programId, Long uploadedBy);
	
	List<CmLibraryProgramCourse> dGetContentByDeptIdProgramIdCourseIdUploadedBy(Long departmentId, Long programId, Long courseId, Long uploadedBy);
	
	List<CmLibraryProgramCourse> dGetContentByDeptIdProgramIdCourseIdContentTypeUploadedBy(Long departmentId, Long programId, Long courseId, Integer contentTypeId, Long uploadedBy);
	
	List<CmLibraryProgramCourse> dGetContentByDeptIdContentTypeUploadedBy(Long departmentId, Integer contentTypeId, Long uploadedBy);
	
	List<CmLibraryProgramCourse> dGetContentByDeptIdProgramIdContentTypeUploadedBy(Long departmentId, Long programId, Integer contentTypeId, Long uploadedBy);
	
	/*
	 * method for count
	 * And for Graphs
	 */
	public Long cmDGetContentCount();
	
	public Long dGetContentCountByMonth(int month, int year);
	
	public Long dGetContentCountByCourseId(Long courseId);
	
	public Long dGetContentCountByCourseIdAndUploadedBy(Long courseId, Long uploadedBy);
	
	List<CmLibraryProgramCourse> dGetContentForAssigned(String title, Integer contentTypeId);
	
	CmLibraryProgramCourse dGetDuplicateContentByTitle(String title);
	
	CmLibraryProgramCourse dGetDuplicateContentByFile(String fileUrl);
	
	
	
	
}
