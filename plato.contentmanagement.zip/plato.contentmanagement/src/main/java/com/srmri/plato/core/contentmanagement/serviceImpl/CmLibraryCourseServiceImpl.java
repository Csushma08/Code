package com.srmri.plato.core.contentmanagement.serviceImpl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.srmri.plato.core.contentmanagement.dao.CmLibraryCourseDao;
import com.srmri.plato.core.contentmanagement.entity.CmLibraryCourse;
import com.srmri.plato.core.contentmanagement.service.CmLibraryCourseService;

/**
 * Business logic Services for interacting with digital library course table
 */

@Service("CmLibraryCourseService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class CmLibraryCourseServiceImpl implements CmLibraryCourseService {

	@Autowired
	private CmLibraryCourseDao libraryCourseDao;

	private final static Logger log = Logger.getLogger(CmLibraryCourseServiceImpl.class.getName());

	/**
	 * Add or update library course content details
	 * 
	 * @param CmLibraryCourse
	 *            libararyCourse
	 * @return boolean true/false for success/failure of addition
	 * @see Table cm_library_course
	 */
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	@Override
	public boolean blAddLibraryCourseContent(CmLibraryCourse libraryCourse) {
		try {
			libraryCourseDao.dAddLibraryCourseContent(libraryCourse);
			return true;
		} catch (Exception e) {
			log.error(
					"blAddLibraryCourseContent::CmLibraryCourseServiceImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return false;
		}
	}

	/**
	 * get list of all digital library course content details
	 * 
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blListAllLibraryCourseContents() {
		return libraryCourseDao.dListAllLibraryCourseContents();
	}

	/**
	 * Get digital library course content details by libraryCourseId
	 * 
	 * @param Long
	 *            libraryCourseId
	 * @return CmLibarayCourse object
	 * @see Table cm_library_course
	 */
	@Override
	public CmLibraryCourse blGetLibraryCourseContent(long libraryCourseId) {
		return libraryCourseDao.dGetLibraryCourseContent(libraryCourseId);
	}

	/**
	 * Delete library course content
	 * 
	 * @param CmLibraryCourse
	 *            libraryCourse content
	 * @return boolean true/false for success/failure of deletion
	 * @see Table cm_library_course
	 */
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	@Override
	public boolean blDeleteLibraryCourseContent(CmLibraryCourse libraryCourse) {
		try {
			libraryCourseDao.dDeleteLibraryCourseContent(libraryCourse);
			return true;
		} catch (Exception e) {
			log.error(
					"blDeleteLibraryCourseContent::CmLibraryCourseServiceImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return false;
		}
	}

	/**
	 * get list of all library course content by matching author name
	 * 
	 * @param String
	 *            author name
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByAuthorName(String author) {
		return libraryCourseDao.dGetContentByAuthorName(author);
	}

	/**
	 * get list of all library course content by matching publisher
	 * 
	 * @param String
	 *            publisher
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByPublisher(String publisher) {
		return libraryCourseDao.dGetContentByPublisher(publisher);
	}

	/**
	 * get list of all library course content by matching year of publication
	 * 
	 * @param String
	 *            year of publication
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByYearOfPublication(String yearPublication) {
		return libraryCourseDao.dGetContentByYearOfPublication(yearPublication);
	}

	/**
	 * get list of all library course content by matching title
	 * 
	 * @param String
	 *            title
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_cours
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByTitle(String title) {
		return libraryCourseDao.dGetContentByTitle(title);
	}

	/**
	 * get list of all library course content by uploaded by (userid of the user
	 * who uploaded the content)
	 * 
	 * @param Long
	 *            uploadedBy
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_course
	 * @author sujata
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByUploadedBy(long uploadedBy) {
		return libraryCourseDao.dGetContentByUploadedBy(uploadedBy);
	}

	/**
	 * Soft Delete library course content
	 * 
	 * @param CmLibraryCourse
	 *            libraryCourse content
	 * @return boolean true/false for success/failure of deletion
	 * @see Table cm_library_course
	 */
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	@Override
	public boolean blSoftDeleteLibraryCourseContent(CmLibraryCourse libraryCourse) {
		try {
			libraryCourseDao.dSoftDeleteLibraryCourseContent(libraryCourse);
			return true;
		} catch (Exception e) {
			log.error(
					"blSoftDeleteLibraryCourseContent::CmLibraryCourseServiceImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return false;
		}

	}

	/**
	 * Restore library course content
	 * 
	 * @param CmLibraryCourse
	 *            libraryCourse content
	 * @return boolean true/false for success/failure of deletion
	 * @see Table cm_library_course
	 */
	@Override
	public boolean blRestoreLibraryCourseContent(CmLibraryCourse libraryCourse) {
		try {
			libraryCourseDao.dRestoreLibraryCourseContent(libraryCourse);
			return true;
		} catch (Exception e) {
			log.error(
					"blRestoreLibraryCourseContent::CmLibraryCourseServiceImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return false;
		}
	}

	/**
	 * get list of all library course content by matching author 
	 * course department map id
	 * @param Long course department map id
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_course
	 */
	
	@Override
	public List<CmLibraryCourse> blGetContentByCourseDepartmentMapId(Long courseDepMapId) {
		return libraryCourseDao.dGetContentByCourseDepartmentMapId(courseDepMapId);
	}

	/**
	 * Get List of Library Course Content 
	 * By passing Department Id
	 * @param Long departmentId
	 * @return list of CmLibraryCourse Objects
	 * @see Table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByDeptId(Long departmentId) {
		
		return libraryCourseDao.dGetContentByDeptId(departmentId);
	}

	/**
	 * Get List of Library Course Content 
	 * By passing Department Id, CourseId
	 * @param Long departmentId, Long courseId
	 * @return list of CmLibraryCourse Objects
	 * @see Table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByDeptIdCourseId(Long departmentId, Long courseId) {
		
		return libraryCourseDao.dGetContentByDeptIdCourseId(departmentId, courseId);
	}

	/**
	 * Get List of Library Course Content 
	 * By passing Department Id, CourseId, ContentType
	 * @param Long departmentId, Long courseId, Integer ContentType
	 * @return list of CmLibraryCourse Objects
	 * @see Table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByDeptIdCourseIdContentType(Long departmentId, Long courseId,
			Integer contentTypeId) {
		
		return libraryCourseDao.dGetContentByDeptIdCourseIdContentType(departmentId, courseId, contentTypeId);
	}

	/**
	 * Get List of Library Course Content 
	 * By passing Department Id, ContentType
	 * @param Long departmentId, Integer ContentType
	 * @return list of CmLibraryCourse Objects
	 * @see Table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByDeptIdAndContentType(Long departmentId, Integer contentTypeId) {
		//
		return libraryCourseDao.dGetContentByDeptIdAndContentType(departmentId, contentTypeId);
	}

	/**
	 * Get List of Library Course Content 
	 * By passing ContentType
	 * @param Integer ContentType
	 * @return list of CmLibraryCourse Objects
	 * @see Table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByContentType(Integer contentType) {
	
		return libraryCourseDao.dGetContentByContentType( contentType);
	}

	/**
	 * Get List of Library Course Content CourseId by sorting     
	 * @return list of CmLibraryCourse Objects
	 * @see Table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByCourseIdSort() {
		return libraryCourseDao.dGetContentByCourseIdSort();
	}

	/**
	 * Get List of Library Course Content 
	 * By passing CourseId
	 * @param Long courseId     
	 * @return list of CmLibraryCourse Objects
	 * @see Table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByCourseId(Long courseId) {
		return libraryCourseDao.dGetContentByCourseId(courseId);
	}
	
	/**
	 * Get List of Library Course Content
	 * By passing Content Type and Course Id
	 * @param Integer contentType, Long courseId
	 * @return list of CmLibraryCourse Objects
	 * @see table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByContentTypeAndCourseId(Integer contentType, Long courseId) {
		return libraryCourseDao.dGetContentByContentTypeAndCourseId(contentType, courseId);
	}

	/**
	 * Get List of Library Course Content
	 * By passing Department Id, UploadedBy
	 * @param Long departmentId, Long uploadedBy
	 * @return list of CmLibraryCourse Objects
	 * @see table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByDeptIdAndUplaodedBy(Long departmentId, Long uploadedBy) {
		return libraryCourseDao.dGetContentByDeptIdAndUploadedBy(departmentId, uploadedBy);
	}

	/**
	 * Get List of Library Course Content
	 * By passing Department Id,Course Id, UploadedBy
	 * @param Long departmentId, Long courseId, Long uploadedBy
	 * @return list of CmLibraryCourse Objects
	 * @see table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByDeptIdCourseIdUploadedBy(Long departmentId, Long courseId,
			Long uploadedBy) {
		return libraryCourseDao.dGetContentByDeptIdCourseIdUploadedBy(departmentId, courseId, uploadedBy);
	}

	/**
	 * Get List of Library Course Content
	 * By passing Department Id,Course Id,Content Type, UploadedBy
	 * @param Long departmentId, Long courseId, Integer contentType, Long uploadedBy
	 * @return list of CmLibraryCourse Objects
	 * @see table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByDeptIdCourseIdContentTypeUploadedBy(Long departmentId, Long courseId,
			Integer contentTypeId, Long uploadedBy) {
		return libraryCourseDao.dGetContentByDeptIdCourseIdContentTypeUploadedBy(departmentId, courseId, contentTypeId, uploadedBy);
	}

	/**
	 * Get List of Library Course Content
	 * By passing Department Id,Content Type, UploadedBy
	 * @param Long departmentId, Integer contentType, Long uploadedBy
	 * @return list of CmLibraryCourse Objects
	 * @see table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByDeptIdAndContentTypeUploadedBy(Long departmentId, Integer contentTypeId,
			Long uploadedBy) {
		return libraryCourseDao.dGetContentByDeptIdAndContentTypeUploadedBy(departmentId, contentTypeId, uploadedBy);
	}

	/**
	 * Get List of Library Course Content
	 * By passing Content Type, UploadedBy
	 * @param Integer contentType, Long uploadedBy
	 * @return list of CmLibraryCourse Objects
	 * @see table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentByContentTypeUploadedBy(Long contentType, Long uploadedBy) {
		return libraryCourseDao.dGetContentByContentTypeAndUploadedBy(contentType, uploadedBy);
	}

	/**
	 * Get List of Library Course Content which are already assigned 
	 * By passing Title,Content Type
	 * @param String title, Integer contentType
	 * @return list of CmLibraryCourse Objects
	 * @see table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> blGetContentForAssigned(String title, Integer contentTypeId) {
		return libraryCourseDao.dGetContentForAssigned(title, contentTypeId);
	}

	/**
	 * Get the already existing title in the table
	 * By passing Title
	 * @param String title
	 * @return CmLibraryCourse Object 
	 * @see table cm_library_course
	 */
	@Override
	public CmLibraryCourse blGetDuplicateContentByTitle(String title) {
		
			return libraryCourseDao.dGetDuplicateContentByTitle(title);
		
	}

	/**
	 * Get the already existing file name in the table
	 * By passing File Url
	 * @param String fileUrl
	 * @return CmLibraryCourse Object 
	 * @see table cm_library_course
	 */
	@Override
	public CmLibraryCourse blGetDuplicateContentByfile(String fileUrl) {
		return libraryCourseDao.dGetDuplicateContentByFile(fileUrl);
	}

	/** 
	 * Get the total number of content by month wise
	 * by passing month and year
	 * @param int month, int year
	 * @return Long
	 * @see table cm_library_course
	 */
	@Override
	public Long blGetContentCountByMonth(int month, int year) {
		return libraryCourseDao.dGetContentCountByMonth(month, year);
	}

	/**
	 * Get the total number of content based on courseId
	 * by passing Course Id
	 * @param Long courseId
	 * @return Long
	 * @see cm_library_course
	 */
	@Override
	public Long blGetContentCountByCourseId(Long courseId) {
		
		return libraryCourseDao.dGetContentCountByCourseId(courseId);
	}

	/**
	 * Get the total number of content based on courseId and uploadedby
	 * @param Long courseId, Long UploadedBy
	 * @return Long
	 * @see cm_library_course
	 *  */
	@Override
	public Long blGetContentCountByCourseIdAndUplaodedBy(Long courseId, Long uploadedBy) {
		return libraryCourseDao.dGetContentCountByCourseIdAndUploadedBy(courseId, uploadedBy);
	}

}
