package com.srmri.plato.core.contentmanagement.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Entity Class for System Info
 *
 */
@Entity
@Table(name= "contentmanagement.cm_system_info")
public class CmSystemInfo implements Serializable{

	private static final long serialVersionUID = 2808690011464502072L;

	@Id        
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator="role_level_seq")
	@SequenceGenerator(name="role_level_seq", sequenceName="contentmanagement.cm_system_info_system_info_id_seq", allocationSize=1)
	@Column(name = "system_info_id")
	private Integer systemInfoId;
	
	@Column(name="info_type")
	private String infoType;
	
	@Column(name="basic_file_path")
	private String basicFilePath;
	
	/**
	 * Getter Method
	 * @return System Info Id
	 */
	public Integer getSystemInfoId() 
	{
		return systemInfoId;
	}

	/**
	 * Setter Method
	 * @param systemInfoId
	 */
	public void setSystemInfoId(Integer systemInfoId) 
	{
		this.systemInfoId = systemInfoId;
	}

	/**
	 * Getter Method
	 * @return Info Type
	 */
	public String getInfoType() 
	{
		return infoType;
	}

	/**
	 * Setter Method
	 * @param infoType
	 */
	public void setInfoType(String infoType) 
	{
		this.infoType = infoType;
	}

	/** 
	 * Getter Method
	 * @return Basic File Path
	 */
	public String getBasicFilePath() 
	{
		return basicFilePath;
	}

	/**
	 * Setter Method
	 * @param basicFilePath
	 */
	public void setBasicFilePath(String basicFilePath) 
	{
		this.basicFilePath = basicFilePath;
	}
	
}
