package com.srmri.plato.core.contentmanagement.dao;

import java.util.List;

import com.srmri.plato.core.contentmanagement.entity.CmContentType;


public interface CmContentTypeDao 
{
	
	/**
	 * Add or update library content type
	 * details
	 * @param CmContentType contentType
	 * @return boolean true/false for success/failure of 
	 * addition
	 * @see Table cm_content_type
	 */
	void dAddContentType(CmContentType contentType);

	/**
	 * get list of all content type details
	 * @return list of CmContentType objects
	 * @see Table cm_content_type
	 */
	List<CmContentType> dListAllContentTypes();
	
	/**
	 * Delete content type details
	 * @param CmContentType contentType
	 * @return boolean true/false for success/failure of
	 * deletion
	 * @see Table cm_content_type
	 */
	void dDeleteContentType(CmContentType contentType);
	
	/**
	 * get content type details by contentTypeId
	 * @param contentTypeId
	 * @return CmContentType object
	 * @see Table cm_content_type
	 */
	CmContentType dGetContentType(int contentTypeId);
	
}
