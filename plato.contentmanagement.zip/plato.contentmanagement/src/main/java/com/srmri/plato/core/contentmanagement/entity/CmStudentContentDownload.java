package com.srmri.plato.core.contentmanagement.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Entity class for Content Download
 */

@Entity
@Table(name= "contentmanagement.cm_student_content_download")
public class CmStudentContentDownload implements Serializable{

	private static final long serialVersionUID = 409179947881249344L;

	@Id        
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="role_level_seq")
	@SequenceGenerator(name="role_level_seq", sequenceName="contentmanagement.cm_student_content_download_student_content_download_id_seq", allocationSize=1)
	@Column(name = "student_content_download_id")
	private long studentContentDownloadId;
	
	@Column(name="student_no")
	private long studentNo;
	
	@Column(name = "digital_library_program_course_id")
	private long libraryProgramCourseId;
	
	@Column(name = "download_date")
	private Date downloadDate;
	
	@Column(name = "digital_library_course_id")
	private long libraryCourseId;
	
	/**
	 * Getter Method
	 * @return Student Download Id
	 */
	public long getStudentContentDownloadId() 
	{
		return studentContentDownloadId;
	}

	/**
	 * Setter Method
	 * @param studentContentDownloadId
	 */
	public void setStudentContentDownloadId(long studentContentDownloadId) 
	{
		this.studentContentDownloadId = studentContentDownloadId;
	}

	/**
	 * Getter Method
	 * @return Student No
	 */
	public long getStudentNo() 
	{
		return studentNo;
	}

	/**
	 * Setter Method
	 * @param studentNo
	 */
	public void setStudentNo(long studentNo) 
	{
		this.studentNo = studentNo;
	}

	/**
	 * Getter Method
	 * @return Library Program Course Id
	 */
	public long getLibraryProgramCourseId() 
	{
		return libraryProgramCourseId;
	}

	/**
	 * Setter Method
	 * @param libraryProgramCourseId
	 */
	public void setLibraryProgramCourseId(long libraryProgramCourseId) {
		this.libraryProgramCourseId = libraryProgramCourseId;
	}

	/**
	 * Getter Method
	 * @return Download Date
	 */
	public Date getDownloadDate() {
		return downloadDate;
	}

	/**
	 * Setter Method
	 * @param downloadDate
	 */
	public void setDownloadDate(Date downloadDate) 
	{
		this.downloadDate = downloadDate;
	}

	/**
	 * Getter Method
	 * @return Library Course Id
	 */
	public long getLibraryCourseId() 
	{
		return libraryCourseId;
	}

	/**
	 * Setter Method
	 * @param libraryCourseId
	 */
	public void setLibraryCourseId(long libraryCourseId) 
	{
		this.libraryCourseId = libraryCourseId;
	}

}
