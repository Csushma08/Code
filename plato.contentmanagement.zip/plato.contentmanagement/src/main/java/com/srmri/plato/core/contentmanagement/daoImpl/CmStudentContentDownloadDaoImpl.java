package com.srmri.plato.core.contentmanagement.daoImpl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.srmri.plato.core.contentmanagement.dao.CmStudentContentDownloadDao;
import com.srmri.plato.core.contentmanagement.entity.CmStudentContentDownload;

/**
 * Data access Services for interacting with student 
 * content download table
 */

@Repository("CmStudentContentDownloadDao")
public class CmStudentContentDownloadDaoImpl implements CmStudentContentDownloadDao
{
	
	@Autowired
	private SessionFactory sessionFactory;
	private final static Logger log = Logger.getLogger(CmStudentContentDownload.class.getName());
	
	/**
	 * Add or update student content download details
	 * @param CmStudentContentDownload studentContentDownload
	 * @see Table cm_student_content_download
	 */
	@Override
	public void dAddStudentContentDownload(CmStudentContentDownload studentContentDownload) 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		session.saveOrUpdate(studentContentDownload);
		}catch(Exception e){
			log.error("dAddStudentContentDownload::CmStudentContentDownloadDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
		}
	}

	/**
	 * get list of all student content download details
	 * @return list of CmStudentContentDownload objects
	 * @see Table cm_student_content_download
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CmStudentContentDownload> dListAllStudentContentDownloads() 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		return (List<CmStudentContentDownload>) session.createCriteria(CmStudentContentDownload.class).list();
		}catch(Exception e){
			log.error("dListAllStudentContentDownloads::CmStudentContentDownloadDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
			return null;
		}
	}

	/**
	 * Delete student content download details
	 * @param CmStudentContentDownload object
	 * @see Table cm_student_content_download
	 */
	@Override
	public void dDeleteStudentContentDownload(CmStudentContentDownload studentContentDownload) 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		session.createQuery("DELETE FROM CmStudentContentDownload WHERE studentContentDownloadId = "+studentContentDownload.getStudentContentDownloadId()).executeUpdate();
		}catch(Exception e){
			log.error("dDeleteStudentContentDownload::CmStudentContentDownloadDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
		}
	}
	
	/**
	 * get student content download details by student content
	 * download id (primary key)
	 * @param Long studentContentDownloadId
	 * @return CmStudentContentDownload object
	 * @see Table cm_student_content_download
	 */
	@Override
	public CmStudentContentDownload dGetStudentContentDownload(long studentContentDownloadId) 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		
		return (CmStudentContentDownload) session.get(CmStudentContentDownload.class, studentContentDownloadId);
		}catch(Exception e){
			log.error("dGetStudentContentDownload::CmStudentContentDownloadDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
			return null;
		}
	}

	
}
