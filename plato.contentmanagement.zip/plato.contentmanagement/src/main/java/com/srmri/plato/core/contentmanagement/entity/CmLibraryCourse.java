package com.srmri.plato.core.contentmanagement.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
/**
 * Entity class for CmLibraryCourse
 */
@Entity
@Table(name= "contentmanagement.cm_digital_library_course")
public class CmLibraryCourse implements Serializable{

	private static final long serialVersionUID = -6394007874666414590L;

	@Id        
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="role_level_seq")
	@SequenceGenerator(name="role_level_seq", sequenceName="contentmanagement.cm_digital_library_course_digital_library_course_id_seq", allocationSize=1)
	@Column(name = "digital_library_course_id")
	private long digitalLibraryCourseId;
	
	@Column(name="course_department_map_id")
	private long courseDepartmentMapId;
	
	@Column(name="content_type_id")
	private Integer contentTypeId;
	
	@Column(name="title")
	private String title;
	
	@Column(name="description")
	private String description;
	
	@Column(name="authors")
	private String author;
	
	@Column(name="publishers")
	private String publisher;
	
	@Column(name="year_of_publication")
	private String yearPublication;
	

	@Column(name="uploaded_by")
	private long uploadedBy;
	

	@Column(name="uploaded_date")
	private Date uploadedDate;
	

	@Column(name="content_tags")
	private String contentTags;
	

	@Column(name="file_url")
	private String fileUrl;
	

	@Column(name="deleted_flag")
	private Integer deletedFlag;
	

	@Column(name="download_count")
	private Integer downloadCount;
	

	@Column(name="last_download_date")
	private Date lastDownloadDate;
	
	@Column(name="deleted_by")
	private Long deletedBy;
	
	@Column(name="deleted_date")
	private Date deletedDate;

	@Column(name="department_id")
	private Long departmentId;
	
	@Column(name="course_id")
	private Long courseId;
	/**
	 * Getter Method
	 * @return LibraryCourseId
	 */
	public long getLibraryCourseId() 
	{
		return digitalLibraryCourseId;
	}

	/**
	 * Setter Method
	 * @param digitalLibraryCourseId
	 */
	public void setLibraryCourseId(long digitalLibraryCourseId) 
	{
		this.digitalLibraryCourseId = digitalLibraryCourseId;
	}

	/**
	 * Getter Method
	 * @return CourseDepartmentMapId
	 */
	public long getCourseDepartmentMapId() 
	{
		return courseDepartmentMapId;
	}

	/**
	 * Setter Method
	 * @param courseDepartmentMapId
	 */
	public void setCourseDepartmentMapId(long courseDepartmentMapId) 
	{
		this.courseDepartmentMapId = courseDepartmentMapId;
	}

	/**
	 * Getter Method
	 * @return ContentTypeId
	 */
	public Integer getContentTypeId() 
	{
		return contentTypeId;
	}

	/**
	 * Setter Method
	 * @param contentTypeId
	 */
	public void setContentTypeId(Integer contentTypeId) 
	{
		this.contentTypeId = contentTypeId;
	}

	/**
	 * Getter Method
	 * @return Title
	 */
	public String getTitle() 
	{
		return title;
	}

	/**
	 * Setter Method
	 * @param title
	 */
	public void setTitle(String title) 
	{
		this.title = title;
	}

	/**
	 * Getter Method
	 * @return Description
	 */
	public String getDescription() 
	{
		return description;
	}

	/**
	 * Setter Method
	 * @param description
	 */
	public void setDescription(String description) 
	{
		this.description = description;
	}

	/**
	 * Getter Method
	 * @return Author
	 */
	public String getAuthor() 
	{
		return author;
	}

	/**
	 * Setter Method
	 * @param author
	 */
	public void setAuthor(String author) 
	{
		this.author = author;
	}

	/**
	 * Getter Method
	 * @return Publisher
	 */
	public String getPublisher() 
	{
		return publisher;
	}

	/**
	 * Setter Method
	 * @param publisher
	 */
	public void setPublisher(String publisher) 
	{
		this.publisher = publisher;
	}

	/**
	 * Getter Method
	 * @return Yeat Of Publications
	 */
	public String getYearPublication() 
	{
		return yearPublication;
	}

	/**
	 * Setter Method
	 * @param yearPublication
	 */
	public void setYearPublication(String yearPublication) 
	{
		this.yearPublication = yearPublication;
	}

	/**
	 * Getter Method
	 * @return Uploaded By
	 */
	public long getUploadedBy() 
	{
		return uploadedBy;
	}

	/**
	 * Setter Method
	 * @param uploadedBy
	 */
	public void setUploadedBy(long uploadedBy) 
	{
		this.uploadedBy = uploadedBy;
	}

	/**
	 * Getter Method
	 * @return Uplaoded Date
	 */
	public Date getUploadedDate() {
		return uploadedDate;
	}

	/**
	 * Setter Method
	 * @param uploaded_date
	 */
	public void setUploadedDate(Date uploaded_date) {
		this.uploadedDate = uploaded_date;
	}

	/**
	 * Getter Method
	 * @return Content Tags
	 */
	public String getContentTags() {
		return contentTags;
	}

	/**
	 * Setter Method
	 * @param content_tags
	 */
	public void setContentTags(String content_tags) {
		this.contentTags = content_tags;
	}

	/**
	 * Getter Method
	 * @return File Url
	 */
	public String getFileUrl() {
		return fileUrl;
	}

	/**
	 * setter Method
	 * @param file_url
	 */
	public void setFileUrl(String file_url) {
		this.fileUrl = file_url;
	}

	/**
	 * Getter Method
	 * @return Deleted Flag
	 */
	public Integer getDeletedFlag() {
		return deletedFlag;
	}

	/**
	 * Setter Method
	 * @param deleted_flag
	 */
	public void setDeletedFlag(Integer deleted_flag) {
		this.deletedFlag = deleted_flag;
	}

	/**
	 * Getter Method
	 * @return Download Count
	 */
	public Integer getDownloadCount() {
		return downloadCount;
	}

	/**
	 * Setter Method
	 * @param download_count
	 */
	public void setDownloadCount(Integer download_count) {
		this.downloadCount = download_count;
	}

	/**
	 * Getter Method
	 * @return Last Download Date
	 */
	public Date getLastDownloadDate() {
		return lastDownloadDate;
	}

	/**
	 * Setter Method
	 * @param last_download_date
	 */
	public void setLastDownloadDate(Date last_download_date) {
		this.lastDownloadDate = last_download_date;
	}
	
	/**
	 * Getter Method
	 * @return Deleted By
	 */
	public Long getDeletedBy(){
		return deletedBy;
	}
	
	/**
	 * Setter Method
	 * @param deletedBy
	 */
	public void setDeletedBy(Long deletedBy){
		this.deletedBy = deletedBy;
	}
	
	/**
	 * Getter Method
	 * @return Deleted Date
	 */
	public Date getDeletedDate(){
		return deletedDate;
	}
	
	/**
	 * Setter Method
	 * @param deletedDate
	 */
	public void setDeletedDate(Date deletedDate){
		this.deletedDate = deletedDate;
	}
	
	/**
	 * Getter Method
	 * @return Department Id
	 */
	public Long getDepartmentId(){
		return departmentId;
	}
	
	/**
	 * Setter Method
	 * @param department Id
	 */
	public void setDepartmentId(Long departmentId){
		this.departmentId = departmentId;
	}
	
	/**
	 * Getter Method
	 * @return course Id
	 */
	public Long getCourseId(){
		return courseId;
	}
	
	/**
	 * Setter Method
	 * @param course Id
	 */
	public void setCourseId(Long courseId){
		this.courseId = courseId;
	}
}
