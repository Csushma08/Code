package com.srmri.plato.core.contentmanagement.service;

import java.util.List;

import com.srmri.plato.core.contentmanagement.entity.CmStudentContentDownload;


public interface CmStudentContentDownloadService 
{
	
	boolean blAddStudentContentDownload(CmStudentContentDownload studentContentDownload);

	List<CmStudentContentDownload> blListAllStudentContentDownloads();
	
	CmStudentContentDownload blGetStudentContentDownload(long studentContentDownloadId);
	
	boolean blDeleteStudentContentDownload(CmStudentContentDownload studentContentDownload);

}
