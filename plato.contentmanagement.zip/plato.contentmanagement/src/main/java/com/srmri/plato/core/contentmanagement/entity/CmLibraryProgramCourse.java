package com.srmri.plato.core.contentmanagement.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Entity class for LibraryProgramCourse
 */

@Entity
@Table(name= "contentmanagement.cm_digital_library_program_course")
public class CmLibraryProgramCourse implements Serializable{
	
	private static final long serialVersionUID = 3699413697368045738L;

	@Id        
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name="role_level_seq", sequenceName="contentmanagement.cm_digital_library_program_course_digital_library_program_course_id_seq", allocationSize=1)
	@Column(name = "digital_library_program_course_id")
	private Long digitalLibraryProgramCourseId;
	
	@Column(name="program_course_map_id")
	private long programCourseMapId;
	
	@Column(name="content_type_id")
	private Integer contentTypeId;
	
	@Column(name="title")
	private String title;
	
	@Column(name="description")
	private String description;
	
	@Column(name="authors")
	private String authors;
	
	@Column(name="publishers")
	private String publisher;
	
	@Column(name="year_of_publication")
	private String yearPublication;
	

	@Column(name="uploaded_by")
	private long uploadedBy;
	

	@Column(name="uploaded_date")
	private Date uploadedDate;
	

	@Column(name="content_tags")
	private String contentTags;
	

	@Column(name="file_url")
	private String fileUrl;
	

	@Column(name="deleted_flag")
	private Integer deletedFlag;
	

	@Column(name="download_count")
	private Integer downloadCount;
	

	@Column(name="last_download_date")
	private Date lastDownloadDate;
	
	@Column(name="deleted_by")
	private Long deletedBy;

	@Column(name="deleted_date")
	private Date deletedDate;
	
	@Column(name="department_id")
	private Long departmentId;
	
	@Column(name="program_id")
	private Long programId;
	
	@Column(name="course_id")
	private Long courseId;

	/**
	 * Getter Method
	 * @return Library Program Course Id
	 */
	public Long getLibraryProgramCourseId() 
	{
		return digitalLibraryProgramCourseId;
	}

	/**
	 * Setter Method
	 * @param digitalLibraryProgramCourseId
	 */
	public void setLibraryProgramCourseId(Long digitalLibraryProgramCourseId) 
	{
		this.digitalLibraryProgramCourseId = digitalLibraryProgramCourseId;
	}

	/**
	 * Getter Method
	 * @return ProgramCourseMapId
	 */
	public long getProgramCourseMapId() {
		return programCourseMapId;
	}

	/**
	 * Setter Method
	 * @param programCourseMapId
	 */
	public void setProgramCourseMapId(long programCourseMapId) 
	{
		this.programCourseMapId = programCourseMapId;
	}

	/**
	 * Getter Method
	 * @return Content Type Id
	 */
	public Integer getContentTypeId() 
	{
		return contentTypeId;
	}

	/**
	 * Setter Method
	 * @param contentTypeId
	 */
	public void setContentTypeId(Integer contentTypeId) 
	{
		this.contentTypeId = contentTypeId;
	}

	/**
	 * Getter Method
	 * @return Title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Setter Method
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Getter Method
	 * @return Description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Setter Method
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Getter Method
	 * @return Author
	 */
	public String getAuthor() {
		return authors;
	}

	/**
	 * Setter Method
	 * @param authors
	 */
	public void setAuthors(String authors) 
	{
		this.authors = authors;
	}

	/**
	 * Getter Method
	 * @return Publisher
	 */
	public String getPublishers() {
		return publisher;
	}

	/**
	 * Setter Method
	 * @param publisher
	 */
	public void setPublisher(String publisher) 
	{
		
		this.publisher = publisher;
	}

	/**
	 * Getter Method
	 * @return Year of Publications
	 */
	public String getYearPublication() 
	{
		return yearPublication;
	}

	/**
	 * Setter Method
	 * @param year_of_publication
	 */
	public void setYearPublication(String year_of_publication) {
		this.yearPublication = year_of_publication;
	}

	/**
	 * Getter Method
	 * @return Uplaoded By
	 */
	public long getUploadedBy() {
		return uploadedBy;
	}

	/**
	 * Setter Method
	 * @param uploadedBy
	 */
	public void setUploadedBy(long uploadedBy) {
		this.uploadedBy = uploadedBy;
	}

	/**
	 * Getter Method
	 * @return Uploaded Date
	 */
	public Date getUploadedDate() {
		return uploadedDate;
	}

	/**
	 * Setter Method
	 * @param uploadedDate
	 */
	public void setUploadedDate(Date uploadedDate) 
	{
		this.uploadedDate = uploadedDate;
	}

	/**
	 * Getter Method
	 * @return Content Tag
	 */
	public String getContentTags() {
		return contentTags;
	}

	/**
	 * Setter Method
	 * @param contentTags
	 */
	public void setContentTags(String contentTags) 
	{
		this.contentTags = contentTags;
	}

	/**
	 * Getter Method
	 * @return File Url
	 */
	public String getFileUrl() 
	{
		return fileUrl;
	}

	/** 
	 * Setter Method
	 * @param fileUrl
	 */
	public void setFileUrl(String fileUrl) 
	{
		this.fileUrl = fileUrl;
	}

	/**
	 * Getter Method
	 * @return Deleted Flag
	 */
	public Integer getDeletedFlag() 
	{
		return deletedFlag;
	}

	/**
	 * Setter Method
	 * @param deletedFlag
	 */
	public void setDeletedFlag(Integer deletedFlag) {
		this.deletedFlag = deletedFlag;
	}

	/**
	 * Getter Method
	 * @return Download Count
	 */
	public Integer getDownloadCount() 
	{
		return downloadCount;
	}

	/**
	 * Setter Method
	 * @param downloadCount
	 */
	public void setDownloadCount(Integer downloadCount) 
	{
		this.downloadCount = downloadCount;
	}

	/**
	 * Getter Method
	 * @return Last Download Date
	 */
	public Date getLastDownloadDate() 
	{
		return lastDownloadDate;
	}

	/**
	 * Setter Method
	 * @param lastDownloadDate
	 */
	public void setLastDownloadDate(Date lastDownloadDate)
	{
		this.lastDownloadDate = lastDownloadDate;
	}
	
	/**
	 * Setter Method
	 * @param deletedBy
	 */
	public void setDeletedBy(Long deletedBy)
	{
		this.deletedBy = deletedBy;
	}
	
	/**
	 * Getter Method
	 * @return Deleted By
	 */
	public Long getDeletedBy()
	{
		return deletedBy;
	}
	
	/**
	 * Setter Method
	 * @param deleted Date
	 */
	public void setDeletedDate(Date deletedDate)
	{
		this.deletedDate = deletedDate;
	}
	
	/**
	 * Getter Method
	 * @return Deleted Date
	 */
	public Date getDeletedDate()
	{
		return deletedDate;
	}
	
	/**
	 * Setter Method
	 * @param Department Id
	 */
	public void setDepartmentId(Long departmentId)
	{
		this.departmentId = departmentId;
	}
	
	/**
	 * Getter Method
	 * @return Department Id
	 */
	public Long getDepartmentId()
	{
		return departmentId;
	}
	
	/**
	 * Setter Method
	 * @param Program Id
	 */
	public void setProgramId(Long programId)
	{
		this.programId = programId;
	}
	
	/**
	 * Getter Method
	 * @return Program Id
	 */
	public Long getProgramId()
	{
		return programId;
	}

	/**
	 * Setter Method
	 * @param Course Id
	 */
	public void setCourseId(Long courseId)
	{
		this.courseId = courseId;
	}
	
	/**
	 * Getter Method
	 * @return Department Id
	 */
	public Long getCourseId()
	{
		return courseId;
	}
}
