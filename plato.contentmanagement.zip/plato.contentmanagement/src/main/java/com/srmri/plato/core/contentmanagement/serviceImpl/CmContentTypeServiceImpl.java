package com.srmri.plato.core.contentmanagement.serviceImpl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import com.srmri.plato.core.contentmanagement.dao.CmContentTypeDao;
import com.srmri.plato.core.contentmanagement.entity.CmContentType;
import com.srmri.plato.core.contentmanagement.service.CmContentTypeService;

/**
 * Business logic Services for interacting with content 
 * type table
 */

@Service("CmContentTypeService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class CmContentTypeServiceImpl implements CmContentTypeService{
	
	@Autowired
	private CmContentTypeDao contentTypeDao;
	
	private final static Logger log = Logger.getLogger(CmContentTypeServiceImpl.class.getName());
	
	/**
	 * get content type details by contentTypeId
	 * @param Integer contentTypeId
	 * @return CmContentType object
	 * @see Table cm_content_type
	 */
	@Transactional
	@Override	
	public CmContentType blGetContentType(int contentTypeId) 
	{
		
		return contentTypeDao.dGetContentType(contentTypeId);
	}
	
	/**
	 * get list of all content type details
	 * @return list of CmContentType objects
	 * @see Table cm_content_type
	 */
	@Override
	public List<CmContentType> blListAllContentTypes() 
	{
		return contentTypeDao.dListAllContentTypes();
	}
	
	
	/**
	 * Add or update library content type
	 * details
	 * @param CmContentType contentType
	 * @return boolean true/false for success/failure of 
	 * addition
	 * @see Table cm_content_type
	 */
	@Override
	public boolean blAddContentType(CmContentType contentType) 
	{
		try
		{
			contentTypeDao.dAddContentType(contentType);
			return true;
		}
		catch(Exception e)
		{
			log.error("blAddContentType::CmContentTypeServiceImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
			return false;
		}
		
	}
	
		
	/**
	 * Delete content type details
	 * @param CmContentType contentType
	 * @return boolean true/false for success/failure of
	 * deletion
	 * @see Table cm_content_type
	 */
	@Override
	public boolean blDeleteContentType(CmContentType contentType) 
	{
		try
		{
			contentTypeDao.dDeleteContentType(contentType);
			return true;
		}
		catch(Exception e)
		{
			log.error("blDeleteContentType::CmContentTypeServiceImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
			return false;
		}
		
	}
	
	
	
}

