package com.srmri.plato.core.contentmanagement.serviceImpl;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.srmri.plato.core.contentmanagement.dao.CmLibraryProgramCourseDao;

import com.srmri.plato.core.contentmanagement.entity.CmLibraryProgramCourse;

import com.srmri.plato.core.contentmanagement.service.CmLibraryProgramCourseService;

/**
 * Business logic Services for interacting with digital 
 * library program course table
 */

@Service("CmLibraryProgramCourse")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class CmLibraryProgramCourseServiceImpl implements CmLibraryProgramCourseService
{
	
	@Autowired
	private CmLibraryProgramCourseDao libraryProgramCourseDao;
	
	private final static Logger log = Logger.getLogger(CmLibraryProgramCourseServiceImpl.class.getName());
	
	/**
	 * Add or update library program course content
	 * details
	 * @param CmLibraryProgramCourse libararyProgramCourse
	 * @return boolean true/false for success/failure of 
	 * addition
	 * @see Table cm_library_program_course
	 */
	@Transactional
	@Override
	public boolean blAddLibraryProgramCourseContent(CmLibraryProgramCourse libraryProgramCourse) 
	{
		
		try
		{
			libraryProgramCourseDao.dAddLibraryProgramCourseContent(libraryProgramCourse);
			return true;
		}
		catch(Exception e)
		{
			log.error("blAddLibraryProgramCourseContent::CmLibraryProgramCourseServiceImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
			return false;
		}
	}
	
	/**
	 * get list of all digital library program course content 
	 * details
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blListAllLibraryProgramCourseContents() 
	{
		
			return libraryProgramCourseDao.dListAllLibraryProgramCourseContents();		
	}

	/**
	 * Get digital libarary program course content details
	 * by libraryProgramCourseId
	 * @param Long libraryProgramCourseId
	 * @return CmLibarayProgramCourse object
	 * @see Table cm_library_program_course
	 */
	@Override
	public CmLibraryProgramCourse blGetLibraryProgramCourseContent(long libraryProgramCourseId) 
	{
				
		return libraryProgramCourseDao.dGetLibraryProgramCourseContent(libraryProgramCourseId);
	}
	
	/**
	 * Delete library program course content
	 * @param CmLibraryProgramCourse libraryProgramCourse content
	 * @return boolean true/false for success/failure of
	 * deletion
	 * @see Table cm_library_program_course
	 */
	@Override
	public boolean blDeleteLibraryProgramCourseContent(CmLibraryProgramCourse libraryProgramCourse) 
	{
		try
		{
			libraryProgramCourseDao.dDeleteLibraryProgramCourseContent(libraryProgramCourse);
			return true;
		}
		catch(Exception e)
		{
			log.error("blDeleteLibraryProgramCourseContent::CmLibraryProgramCourseServiceImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
			return false;
		}
		
	}
	
	/**
	 * get list of all library program course content by 
	 * matching title
	 * @param String title
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByTitle(String title) 
	{
	
		return libraryProgramCourseDao.dGetContentByTitle(title);

	}
	
	/**
	 * get list of all library program course content by 
	 * matching author
	 * @param String author
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByAuthorName(String author) {
			
		return libraryProgramCourseDao.dGetContentByAuthorName(author);
		
	}
	
	/**
	 * get list of all library program course content by 
	 * matching publisher
	 * @param String publisher
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByPublisher(String publisher) 
	{
			
		return libraryProgramCourseDao.dGetContentByPublisher(publisher);

	}
	
	/**
	 * get list of all library program course content by 
	 * matching year of publication
	 * @param String year of publication
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByYearOfPublication(String yearPublication) 
	{
			
		return libraryProgramCourseDao.dGetContentByYearOfPublication(yearPublication);
	
	}
	
	/**
	 * get list of all library program course content by 
	 * uploaded by (userid of the user who uploaded the content)
	 * @param Long uploadedBy
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByUploadedBy(long uploadedBy) {
			
		return libraryProgramCourseDao.dGetContentByUploadedBy(uploadedBy);
	
	}
	
	/**
	 * Soft Delete library program course content
	 * @param CmLibraryProgramCourse libraryProgramCourse content
	 * @return boolean true/false for success/failure of
	 * deletion
	 * @see Table cm_library_program_course
	 */
	@Transactional
	@Override
	public boolean blSoftDeleteLibraryProgramCourseContent(CmLibraryProgramCourse libraryProgramCourse) {
		
		try{
			libraryProgramCourseDao.dSoftDeleteLibraryProgramCourseContent(libraryProgramCourse);
			return true;
		}
		catch(Exception e)
		{
			log.error("blSoftDeleteLibraryProgramCourseContent::CmLibraryProgramCourseServiceImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
			//e.printStackTrace();
			return false;
		}
		
	}
	
	/**
	 * Restore library program course content
	 * @param CmLibraryProgramCourse libraryProgramCourse content
	 * @return boolean true/false for success/failure of
	 * deletion
	 * @see Table cm_library_program_course
	 */
	@Transactional
	@Override
	public boolean blRestoreLibraryProgramCourseContent(CmLibraryProgramCourse libraryProgramCourse) {
		try{
			libraryProgramCourseDao.dRestoreLibraryProgramCourseContent(libraryProgramCourse);
			return true;
		}
		catch(Exception e)
		{
			log.error("blRestoreLibraryProgramCourseContent::CmLibraryProgramCourseServiceImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
			//e.printStackTrace();
			return false;
		}
		
	}


	/**
	 * get list of all library program course content by 
	 * matching program course map id
	 * @param Long program course map id
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByProgramCourseMapId(Long programCourseMapId) {
		
		return libraryProgramCourseDao.dGetContentByProgramCourseMapId(programCourseMapId);
	}

	/**
	 * get list of all library program course content by 
	 * matching department id
	 * @param Long departmentId
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByDeptId(Long departmentId) {
		return libraryProgramCourseDao.dGetContentByDeptId(departmentId);
	}

	/**
	 * get list of all library program course content by 
	 * matching department id, program Id
	 * @param Long departmentId, Long programId
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByDeptIdAndProgramId(Long departmentId, Long programId) {
	
		return libraryProgramCourseDao.dGetContentByDeptIdAndProgramId(departmentId, programId);
	}

	/**
	 * get list of all library program course content by 
	 * matching department id, program id, course id
	 * @param Long departmentId, Long programId, Long courseId
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByDeptIdProgramIdCourseId(Long departmentId, Long programId,
			Long courseId) {
		return libraryProgramCourseDao.dGetContentByDeptIdProgramIdCourseId(departmentId, programId, courseId);
	}

	/**
	 * get list of all library program course content by 
	 * matching department id, program id, course id, content type id
	 * @param Long departmentId, Long programId, Long courseId, Integer contentTypeId
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByDeptIdProgramIdCourseIdContentType(Long departmentId,
			Long programId, Long courseId, Integer contentTypeId) {
		return libraryProgramCourseDao.dGetContentByDeptIdProgramIdCourseIdContentType(departmentId, programId, courseId, contentTypeId);
	}

	/**
	 * get list of all library program course content by 
	 * matching department id, content type
	 * @param Long departmentId, Integer contentTypeId
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByDeptIdAndContentType(Long departmentId, Integer contentTypeId) {
		return libraryProgramCourseDao.dGetContentByDeptIdAndContentType(departmentId, contentTypeId);
	}

	/**
	 * get list of all library program course content by 
	 * matching department id, program id, content type id
	 * @param Long departmentId, Long programId, Integer contentTypeId
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByDeptIdProgramIdContentType(Long departmentId, Long programId,
			Integer contentTypeId) {
		return libraryProgramCourseDao.dGetContentByDeptIdProgramIdContentType(departmentId, programId, contentTypeId);
	}

	/**
	 * get list of all library program course content by 
	 * matching department id, content type id
	 * @param Long departmentId, Integer contentTypeId
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByContentType(Integer contentType, Long programId) {
		// TODO Auto-generated method stub
		return libraryProgramCourseDao.dGetContentByContentType(contentType, programId); 
	}

	/**
	 * get list of all library program course
	 * matching course id with sort according to alphabet order
	 * @return list of CmLibraryProgramCourse objects 
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByCourseIdSort() {
		return libraryProgramCourseDao.dGetContentByCourseIdSort();
	}

	/**
	 * get list of all library course
	 * matching course id
	 * @param Long courseId
	 * @return list od CmLibraryProgramCourse object
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByCourseId(Long courseId) {
		return libraryProgramCourseDao.dGetContentByCourseId(courseId);
	}

	/**
	 * get list of all library program course content by 
	 * matching content type, course id
	 * @param Integer contentTypeId, Long courseId
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByContentTypeAndCourseId(Integer contentType, Long courseId) {
		
		return libraryProgramCourseDao.dGetContentByContentTypeAndCourseId(contentType, courseId);
	}

	/**
	 * get list of all library program course content by 
	 * matching department id, uploadedBy
	 * @param Long departmentId, Long uploadedBy
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByDeptIdAndUploadedBy(Long departmentId, Long uploadedBy) {
		
		return libraryProgramCourseDao.dGetContentByDeptIdAndUploadedBy(departmentId, uploadedBy);
	}

	/**
	 * get list of all library program course content by 
	 * matching department id, program id, uplaodedBy
	 * @param Long departmentId, Long programId, Long uploaedeBy
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByDeptIdProgramIdUploadedBy(Long departmentId, Long programId,
			Long uploadedBy) {
		
		return libraryProgramCourseDao.dGetContentByDeptIdProgramIdUploadedBy(departmentId, programId, uploadedBy);
	}

	/**
	 * get list of all library program course content by 
	 * matching department id, program id, course id, uplaodedBy
	 * @param Long departmentId, Long programId, Long courseId, Long uploaedeBy
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByDeptIdProgramIdCourseIdUplodedBy(Long departmentId,
			Long programId, Long courseId, Long uploadedBy) {

		return libraryProgramCourseDao.dGetContentByDeptIdProgramIdCourseIdUploadedBy(departmentId, programId, courseId, uploadedBy);
	}

	/**
	 * get list of all library program course content by 
	 * matching department id, program id, course id, uplaodedBy, content type
	 * @param Long departmentId, Long programId, Long courseId, Long uploaedeBy, Integer contentTypeId
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByDeptIdProgramIdCourseIdContentTypeUploadedBy(Long departmentId,
			Long programId, Long courseId, Integer contentTypeId, Long uploadedBy) {

		return libraryProgramCourseDao.dGetContentByDeptIdProgramIdCourseIdContentTypeUploadedBy(departmentId, programId, courseId, contentTypeId, uploadedBy);
	}

	/**
	 * get list of all library program course content by 
	 * matching department id, uplaodedBy, content type
	 * @param Long departmentId, Long uploaedeBy, Integer contentTypeId
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByDeptIdContentTypeUploadedBy(Long departmentId,
			Integer contentTypeId, Long uploadedBy) {

		return libraryProgramCourseDao.dGetContentByDeptIdContentTypeUploadedBy(departmentId, contentTypeId, uploadedBy);
	}

	/**
	 * get list of all library program course content by 
	 * matching department id, program id, uplaodedBy, content type
	 * @param Long departmentId, Long programId, Long uploaedeBy, Integer contentTypeId
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByDeptIdProgramIdContentTypeUploadedBy(Long departmentId,
			Long programId, Integer contentTypeId, Long uploadedBy) {
		return libraryProgramCourseDao.dGetContentByDeptIdProgramIdContentTypeUploadedBy(departmentId, programId, contentTypeId, uploadedBy);
	}

	/**
	 * get list of all library program course content by 
	 * matching content type
	 * @param Integer contentTypeId
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentByContentType(Integer contentType) {
		return libraryProgramCourseDao.dGetContentByContentType(contentType);
	}

	/**
	 * get total number of content for both the tables 
	 * @return Long
	 * @see Table cm_library_course, cm_library_program_course
	 */
	@Override
	public Long blGetContentCount() {
		return libraryProgramCourseDao.cmDGetContentCount();
	}

	/**
	 * get list of content assiged to same title and content type
	 * @param String title, Integer contentTypeId
	 * @see Table cm_libray_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> blGetContentForAssigned(String title, Integer contentTypeId) {
		return libraryProgramCourseDao.dGetContentForAssigned(title, contentTypeId);
	}

	/**
	 * get content with is already existing with the same title which we passed
	 * @param String title
	 * @return CmlibraryProgramCourse object
	 * @see cm_library_program_course
	 */
	@Override
	public CmLibraryProgramCourse blGetDuplicateContentByTitle(String title) {
		
			return libraryProgramCourseDao.dGetDuplicateContentByTitle(title);
	}
	
	/**
	 * get content with is already existing with same file name
	 * @param String fileUrl
	 * @return CmLibraryPrgoramCourse Object
	 * @see Table cm_library_program_course
	 */
	@Override
	public CmLibraryProgramCourse blGetDuplicateContentByfile(String fileUrl) {
		
			return libraryProgramCourseDao.dGetDuplicateContentByFile(fileUrl);
			
	}

	/**
	 * get content count for past 6 Months
	 * from Current month and year
	 * @param int month, int year
	 * @return Long
	 * @see Table cm_library_program_course
	 */
	@Override
	public Long blGetContentCountByMonth(int month, int year) {
		
		return libraryProgramCourseDao.dGetContentCountByMonth(month, year);
	}

	/**
	 * get content count for course id
	 * @param Long courseId
	 * @return Long
	 * @see Table cm_library_program_course
	 */
	@Override
	public Long blGetContentCountByCourseId(Long courseId) {
		return libraryProgramCourseDao.dGetContentCountByCourseId(courseId);
	}

	/**
	 * get content count for course id and uploadedBy
	 * @param Long courseId, Long uplaodedBy
	 * @return Long
	 * @see Table cm_library_program_course
	 */
	@Override
	public Long blGetContentCountByCourseIdAndUploadedBy(Long courseId, Long uploadedBy) {
		return libraryProgramCourseDao.dGetContentCountByCourseIdAndUploadedBy(courseId, uploadedBy);
	}
	
	
	
   
}
