package com.srmri.plato.core.contentmanagement.dao;

import java.util.List;

import com.srmri.plato.core.contentmanagement.entity.CmSystemInfo;

public interface CmSystemInfoDao 
{
	void dAddSystemInfo(CmSystemInfo systemInfo);

	List<CmSystemInfo> dListAllSystemInfos();
	
	CmSystemInfo dGetSystemInfo(int systemInfoId);
	
	void dDeleteSystemInfo(CmSystemInfo SystemInfo);
	
	
	
}
 