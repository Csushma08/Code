package com.srmri.plato.core.contentmanagement.dao;

import java.util.List;

import com.srmri.plato.core.contentmanagement.entity.CmStudentContentDownload;


public interface CmStudentContentDownloadDao 
{
	void dAddStudentContentDownload(CmStudentContentDownload contentDownload);

	List<CmStudentContentDownload> dListAllStudentContentDownloads();
	
	CmStudentContentDownload dGetStudentContentDownload(long studentContentDownloadId);
	
	void dDeleteStudentContentDownload(CmStudentContentDownload studentContentDownload);

}
