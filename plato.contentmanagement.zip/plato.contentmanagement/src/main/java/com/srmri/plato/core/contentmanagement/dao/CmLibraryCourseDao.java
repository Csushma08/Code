package com.srmri.plato.core.contentmanagement.dao;

import java.util.List;

import com.srmri.plato.core.contentmanagement.entity.CmLibraryCourse;
import com.srmri.plato.core.contentmanagement.entity.CmLibraryProgramCourse;

public interface CmLibraryCourseDao 
{
	
	
	void dAddLibraryCourseContent(CmLibraryCourse libraryCourse);

	List<CmLibraryCourse> dListAllLibraryCourseContents();

	CmLibraryCourse dGetLibraryCourseContent(long libraryCourseId);

	void dDeleteLibraryCourseContent(CmLibraryCourse libraryCourse);

	List<CmLibraryCourse> dGetContentByYearOfPublication(String yearPublication);

	List<CmLibraryCourse> dGetContentByPublisher(String publisher);

	List<CmLibraryCourse> dGetContentByAuthorName(String author);
	
	List<CmLibraryCourse> dGetContentByTitle(String title);
	
	List<CmLibraryCourse> dGetContentByUploadedBy(long uploadedBy);
	
	void dSoftDeleteLibraryCourseContent(CmLibraryCourse libraryCourse);
	
	void dRestoreLibraryCourseContent(CmLibraryCourse libraryCourse);
	
	List<CmLibraryCourse> dGetContentByCourseDepartmentMapId(Long courseDepMapId);
	
	List<CmLibraryCourse> dGetContentByDeptId(Long departmentId);
	
	List<CmLibraryCourse> dGetContentByDeptIdCourseId(Long departmentId, Long courseId);
	
	List<CmLibraryCourse> dGetContentByDeptIdCourseIdContentType(Long departmentId, Long courseId, Integer contentTypeId);
	
	List<CmLibraryCourse> dGetContentByDeptIdAndContentType(Long departmentId, Integer contentTypeId);
	
	List<CmLibraryCourse> dGetContentByContentTypeAndCourseId(Integer contentType, Long courseId);
	
	List<CmLibraryCourse> dGetContentByContentType(Integer contentType);
	
	List<CmLibraryCourse> dGetContentByCourseIdSort();
	
	List<CmLibraryCourse> dGetContentByCourseId(Long courseId);
	
	List<CmLibraryCourse> dGetContentByDeptIdAndUploadedBy(Long departmentId, Long uploadedBy);
	
	List<CmLibraryCourse> dGetContentByDeptIdCourseIdUploadedBy(Long departmentId, Long courseId, Long uploadedBy);
	
	List<CmLibraryCourse> dGetContentByDeptIdCourseIdContentTypeUploadedBy(Long departmentId, Long courseId, Integer contentTypeId, Long uploadedBy);
	
	List<CmLibraryCourse> dGetContentByDeptIdAndContentTypeUploadedBy(Long departmentId, Integer contentTypeId, Long uploadedBy);
	
	List<CmLibraryCourse> dGetContentByContentTypeAndUploadedBy(Long contentType, Long uploadedBy);
	
	List<CmLibraryCourse> dGetContentForAssigned(String title, Integer contentTypeId);
	
	CmLibraryCourse dGetDuplicateContentByTitle(String title);
	
	CmLibraryCourse dGetDuplicateContentByFile(String fileUrl);
	
	public Long dGetContentCountByMonth(int month, int year);
	
	public Long dGetContentCountByCourseId(Long courseId);
	
	public Long dGetContentCountByCourseIdAndUploadedBy(Long courseId, Long uploadedBy);
	
}
