package com.srmri.plato.core.contentmanagement.daoImpl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.srmri.plato.core.contentmanagement.dao.CmSystemInfoDao;
import com.srmri.plato.core.contentmanagement.entity.CmSystemInfo;

/**
 * Data access Services for interacting with system info
 * table
 */

@Repository("CmSystemInfoDao")
public class CmSystemInfoDaoImpl implements CmSystemInfoDao
{
	

	@Autowired
	private SessionFactory sessionFactory;

	private final static Logger log = Logger.getLogger(CmSystemInfoDaoImpl.class.getName());

	/**
	 * Add or update system info details
	 * @param CmSystemInfo systemInfo
	 * @see Table cm_system_info
	 */
	@Override
	public void dAddSystemInfo(CmSystemInfo systemInfo) 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		session.saveOrUpdate(systemInfo);
		}catch(Exception e){
			log.error("dAddSystemInfo::CmSystemInfoDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
		}
	
	}

	/**
	 * get list of all system infor details
	 * @return list of CmSystemInfo objects
	 * @see Table cm_system_info
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CmSystemInfo> dListAllSystemInfos() 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		return (List<CmSystemInfo>) session.createCriteria(CmSystemInfo.class).list();
		}catch(Exception e){
			log.error("dListAllSystemInfos::CmSystemInfoDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
			return null;
		}
	}
	
	/**
	 * get system info details by system info id (primary
	 * key)
	 * @param Integer systemInfoId
	 * @return CmSystemInfo object
	 * @see Table cm_system_info
	 */
	@Override
	public CmSystemInfo dGetSystemInfo(int systemInfoId) 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		return (CmSystemInfo) session.get(CmSystemInfo.class, systemInfoId);
		}catch(Exception e){
			log.error("dGetSystemInfo::CmSystemInfoDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
			return null;
		}
	}

	/**
	 * Delete system info details
	 * @param CmSystemInfo systemInfo 
	 * @see Table cm_system_info
	 */
	@Override
	public void dDeleteSystemInfo(CmSystemInfo systemInfo)
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		session.createQuery("DELETE FROM CmSystemInfo WHERE systemInfoId = "+systemInfo.getSystemInfoId()).executeUpdate();
		}catch(Exception e){
			log.error("dDeleteSystemInfo::CmSystemInfoDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
		}
	}

	

}
