package com.srmri.plato.core.contentmanagement.daoImpl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.srmri.plato.core.contentmanagement.dao.CmLibraryProgramCourseDao;
import com.srmri.plato.core.contentmanagement.entity.CmLibraryCourse;
import com.srmri.plato.core.contentmanagement.entity.CmLibraryProgramCourse;
import com.srmri.plato.core.contentmanagement.entity.EscapedRestrictions;

/**
 * Data access Services for interacting with digital library program course
 * table
 */

@Repository("CmLibraryProgramCourseDao")
public class CmLibraryProgramCourseDaoImpl implements CmLibraryProgramCourseDao {

	@Autowired
	private SessionFactory sessionFactory;

	private final static Logger log = Logger.getLogger(CmLibraryProgramCourseDaoImpl.class.getName());

	/**
	 * Add or update library program course content details
	 * 
	 * @param CmLibraryProgramCourse
	 *            libraryProgramCourse
	 * @see Table cm_library_program_course
	 */
	@Override
	public void dAddLibraryProgramCourseContent(CmLibraryProgramCourse libraryProgramCourse) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.saveOrUpdate(libraryProgramCourse);
		} catch (Exception e) {
			log.error(
					"dAddLibraryProgramCourseContent::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
		}
	}

	/**
	 * get list of all library program course content details
	 * 
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CmLibraryProgramCourse> dListAllLibraryProgramCourseContents() {
		try {
			Session session = sessionFactory.getCurrentSession();
			return (List<CmLibraryProgramCourse>) session.createCriteria(CmLibraryProgramCourse.class).list();
		} catch (Exception e) {
			log.error(
					"dListAllLibraryProgramCourseContent::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	/**
	 * get library program course content details by digital library program
	 * course id
	 * 
	 * @param Long
	 *            libraryProgramCourseId
	 * @return CmLibraryProgramCourse object
	 * @see Table cm_library_program_course
	 */
	@Override
	public CmLibraryProgramCourse dGetLibraryProgramCourseContent(long libraryProgramCourseId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			return (CmLibraryProgramCourse) session.get(CmLibraryProgramCourse.class, libraryProgramCourseId);
		} catch (Exception e) {
			log.error(
					"dGetLibraryProgramCourseContent::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	/**
	 * delete library program course content details
	 * 
	 * @param CmLibraryProgramCourse
	 *            libraryProgramCourse
	 * @see Table cm_library_program_course
	 */
	@Override
	public void dDeleteLibraryProgramCourseContent(CmLibraryProgramCourse libraryProgramCourse) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.createQuery("DELETE FROM CmLibraryProgramCourse WHERE libraryProgramCourseId = "
					+ libraryProgramCourse.getLibraryProgramCourseId()).executeUpdate();
		} catch (Exception e) {
			log.error(
					"dDeleteLibraryProgramCourseContent::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
		}
	}

	/**
	 * get digital library program course content details by author name
	 * 
	 * @param String
	 *            author name
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_program_course
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CmLibraryProgramCourse> dGetContentByAuthorName(String author) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("authors", author));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByAuthorName::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}

	}

	/**
	 * get digital library program course content details by publisher
	 * 
	 * @param String
	 *            publisher
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_program_course
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CmLibraryProgramCourse> dGetContentByPublisher(String publisher) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("publisher", publisher));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByPublisher::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}

	}

	/**
	 * get digital library program course content details by year of publication
	 * 
	 * @param String
	 *            year of publication
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_program_course
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CmLibraryProgramCourse> dGetContentByYearOfPublication(String yearPublication) {
		try {
			Session session = sessionFactory.getCurrentSession();

			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("yearPublication", yearPublication));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByYearOfPublication::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}

	}

	/**
	 * get digital library program course content details by uploaded by
	 * 
	 * @param Long
	 *            uploaded by
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_program_course
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CmLibraryProgramCourse> dGetContentByUploadedBy(long uploadedBy) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("uploadedBy", uploadedBy));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByUplaodedBy::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}

	}

	/**
	 * get digital library program course content details by title
	 * 
	 * @param String
	 *            title
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_program_course
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CmLibraryProgramCourse> dGetContentByTitle(String title) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("title", title));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByTitle::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}

	}

	/**
	 * Soft Delete library program course content details
	 * 
	 * @param CmLibraryProgramCourse
	 *            libraryProgramCourse
	 * @see Table cm_library_program_course
	 */
	@Override
	public void dSoftDeleteLibraryProgramCourseContent(CmLibraryProgramCourse libraryProgramCourse) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.createQuery("UPDATE CmLibraryProgramCourse SET deletedFlag=1 WHERE digitalLibraryProgramCourseId = "
					+ libraryProgramCourse.getLibraryProgramCourseId()).executeUpdate();
		} catch (Exception e) {
			log.error(
					"dSoftDeleteLibraryProgramCourseContent::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
		}

	}

	/**
	 * Restore library program course content details
	 * 
	 * @param CmLibraryProgramCourse
	 *            libraryProgramCourse
	 * @see Table cm_library_program_course
	 */
	@Override
	public void dRestoreLibraryProgramCourseContent(CmLibraryProgramCourse libraryProgramCourse) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.createQuery("UPDATE CmLibraryProgramCourse SET deletedFlag=0 WHERE digitalLibraryProgramCourseId = "
					+ libraryProgramCourse.getLibraryProgramCourseId()).executeUpdate();
		} catch (Exception e) {
			log.error(
					"dRestoreLibraryProgramCourseContent::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
		}

	}

	/**
	 * get digital library program course content details by program course map
	 * id
	 * 
	 * @param Long
	 *            program course map id
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> dGetContentByProgramCourseMapId(long programCourseMapId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("programCourseMapId", programCourseMapId));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByProgramCourseMapId::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}

	}

	/**
	 * get digital library program course content details by departmentId
	 * 
	 * @param Long
	 *            department id
	 * @return list of CmLibraryProgramCourse objects
	 * @see Table cm_library_program_course
	 */
	@Override
	public List<CmLibraryProgramCourse> dGetContentByDeptId(Long departmentId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("departmentId", departmentId));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByDeptId::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	/**
	 * Fetching the content by passing deptId and programId
	 * 
	 * @param DepartmentId,
	 *            programId
	 * @return List of object
	 * @see table Cm_Digital_program_Course
	 */

	@Override
	public List<CmLibraryProgramCourse> dGetContentByDeptIdAndProgramId(Long departmentId, Long programId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("programId", programId));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByDeptIdAndProgramId::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	/**
	 * Fetching the content by passing deptId, programId and couserId
	 * 
	 * @param DepartmentId,
	 *            programId, courseId
	 * @return List of object
	 * @see table Cm_Digital_program_Course
	 */

	@Override
	public List<CmLibraryProgramCourse> dGetContentByDeptIdProgramIdCourseId(Long departmentId, Long programId,
			Long courseId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("programId", programId));
			cr.add(Restrictions.eq("courseId", courseId));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByDeptIdProgramIdCourseId::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}

	}

	/**
	 * Fetching the content by passing deptId, programId, courseId and
	 * contentType
	 * 
	 * @param DepartmentId,
	 *            programId, courseId, contentType
	 * @return List of object
	 * @see table Cm_Digital_program_Course
	 */

	@Override
	public List<CmLibraryProgramCourse> dGetContentByDeptIdProgramIdCourseIdContentType(Long departmentId,
			Long programId, Long courseId, Integer contentTypeId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("programId", programId));
			cr.add(Restrictions.eq("courseId", courseId));
			cr.add(Restrictions.eq("contentTypeId", contentTypeId));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByDeptIdProgramIdCourseIdContentType::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	/**
	 * Fetching the content by passing deptId and contentType
	 * 
	 * @param DepartmentId,
	 *            contentType
	 * @return List of object
	 * @see table Cm_Digital_program_Course
	 */

	@Override
	public List<CmLibraryProgramCourse> dGetContentByDeptIdAndContentType(Long departmentId, Integer contentTypeId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("contentTypeId", contentTypeId));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByDeptIdAndContentType::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	/**
	 * Fetching the content by passing deptId and programId and contentType
	 * 
	 * @param DepartmentId,
	 *            programId, contentType
	 * @return List of object
	 * @see table Cm_Digital_program_Course
	 */
	@Override
	public List<CmLibraryProgramCourse> dGetContentByDeptIdProgramIdContentType(Long departmentId, Long programId,
			Integer contentTypeId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("programId", programId));
			cr.add(Restrictions.eq("contentTypeId", contentTypeId));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByDeptIdProgramIdContentType::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	@Override
	public List<CmLibraryProgramCourse> dGetContentByContentType(Integer contentType, Long programId) {
		// TODO Auto-generated method stub
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("contentTypeId", contentType));
			cr.add(Restrictions.eq("programId", programId));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByContentType::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	@Override
	public List<CmLibraryProgramCourse> dGetContentByContentTypeAndCourseId(Integer contentType, Long courseId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("contentTypeId", contentType));
			cr.add(Restrictions.eq("courseId", courseId));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByContentTypeAndCourseId::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	@Override
	public List<CmLibraryProgramCourse> dGetContentByCourseIdSort() {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria crProgramCourses = session.createCriteria(CmLibraryProgramCourse.class);
			/*crProgramCourses.add(Restrictions.eq("deletedFlag", 0));*/

			crProgramCourses
					.setProjection(Projections.projectionList().add(Projections.groupProperty("courseId"), "courseId"));
			crProgramCourses.setResultTransformer(Transformers.aliasToBean(CmLibraryProgramCourse.class));
			@SuppressWarnings("unchecked")
			List<CmLibraryProgramCourse> courseList = crProgramCourses.list();
			return courseList;
		} catch (Exception e) {
			log.error(
					"dGetContentByCourseIdSort::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}

	}

	@Override

	public List<CmLibraryProgramCourse> dGetContentByCourseId(Long courseId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("courseId", courseId));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByCourseId::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	@Override
	public List<CmLibraryProgramCourse> dGetContentByDeptIdAndUploadedBy(Long departmentId, Long uploadedBy) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("uploadedBy", uploadedBy));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByDeptIdAndUploadedBy::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	@Override
	public List<CmLibraryProgramCourse> dGetContentByDeptIdProgramIdUploadedBy(Long departmentId, Long programId,
			Long uploadedBy) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("programId", programId));
			cr.add(Restrictions.eq("uploadedBy", uploadedBy));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByDeptIdProgramIdUploadedBy::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	@Override
	public List<CmLibraryProgramCourse> dGetContentByDeptIdProgramIdCourseIdUploadedBy(Long departmentId,
			Long programId, Long courseId, Long uploadedBy) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("programId", programId));
			cr.add(Restrictions.eq("courseId", courseId));
			cr.add(Restrictions.eq("uploadedBy", uploadedBy));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByDeptIdProgramIdCourseIdUploadedBy::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	@Override
	public List<CmLibraryProgramCourse> dGetContentByDeptIdProgramIdCourseIdContentTypeUploadedBy(Long departmentId,
			Long programId, Long courseId, Integer contentTypeId, Long uploadedBy) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("programId", programId));
			cr.add(Restrictions.eq("courseId", courseId));
			cr.add(Restrictions.eq("contentTypeId", contentTypeId));
			cr.add(Restrictions.eq("contentTypeId", contentTypeId));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByDeptIdProgramIdCourseIdContentTypeUploadedBy::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	@Override
	public List<CmLibraryProgramCourse> dGetContentByDeptIdContentTypeUploadedBy(Long departmentId,
			Integer contentTypeId, Long uploadedBy) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("contentTypeId", contentTypeId));
			cr.add(Restrictions.eq("uploadedBy", uploadedBy));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByDeptIdContentTypeUploadedBy::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	@Override
	public List<CmLibraryProgramCourse> dGetContentByDeptIdProgramIdContentTypeUploadedBy(Long departmentId,
			Long programId, Integer contentTypeId, Long uploadedBy) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("programId", programId));
			cr.add(Restrictions.eq("contentTypeId", contentTypeId));
			cr.add(Restrictions.eq("uploadedBy", uploadedBy));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByDeptIdProgramIdContentTypeUploadedBy::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	@Override
	public List<CmLibraryProgramCourse> dGetContentByContentType(Integer contentType) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("contentTypeId", contentType));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentByContentType::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}
	}

	@Override
	public Long cmDGetContentCount() {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria crit = session.createCriteria(CmLibraryProgramCourse.class);
			crit.add(Restrictions.eq("deletedFlag", 0));
			crit.setProjection(Projections.rowCount());
			Long count = (Long) crit.uniqueResult();

			Criteria crit1 = session.createCriteria(CmLibraryCourse.class);
			crit1.add(Restrictions.eq("deletedFlag", 0));
			crit1.setProjection(Projections.rowCount());
			Long count1 = (Long) crit1.uniqueResult();
			Long finalCount = (long) count + (long) count1;
			return finalCount;
		} catch (Exception e) {
			log.error(
					"cmDGetContentCount::CmLibraryProgramCourseDaoImpl::ContentManagement:: Plato Threw a BadException, full stack trace follows:",
					e);
			return null;
		}

	}

	@Override
	public List<CmLibraryProgramCourse> dGetContentForAssigned(String title, Integer contentTypeId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);

			cr.add(Restrictions.eq("title", title));
			cr.add(Restrictions.eq("contentTypeId", contentTypeId));
			cr.add(Restrictions.eq("deletedFlag", 0));

			return (List<CmLibraryProgramCourse>) cr.list();
		} catch (Exception e) {
			log.error(
					"dGetContentForAssigned::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return null;
		}

	}

	@Override
	public CmLibraryProgramCourse dGetDuplicateContentByTitle(String title) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria getContentByNameCriteria = session.createCriteria(CmLibraryProgramCourse.class);

			getContentByNameCriteria.add(Restrictions.eq("title", title));
			return (CmLibraryProgramCourse) getContentByNameCriteria.uniqueResult();

		} catch (Exception e) {
			log.error(
					"dGetDuplicateContentByTitle::CmLibraryProgramCourseDaoImpl::ContentManagement:: Plato Threw a BadException, full stack trace follows:",
					e);
			return null;
		}
	}

	@Override
	public CmLibraryProgramCourse dGetDuplicateContentByFile(String fileUrl) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria getContentByNameCriteria = session.createCriteria(CmLibraryProgramCourse.class);

			getContentByNameCriteria.add(EscapedRestrictions.ilike("fileUrl", fileUrl, MatchMode.EXACT));
			return (CmLibraryProgramCourse) getContentByNameCriteria.uniqueResult();

		} catch (Exception e) {
			log.error(
					"dGetDuplicateContentByFile::CmLibraryProgramCourseDaoImpl::ContentManagement:: Plato Threw a BadException, full stack trace follows:",
					e);
			return null;
		}
	}

	
	@Override
	public Long dGetContentCountByMonth(int month, int year) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);
			cr.add(Restrictions.eq("deletedFlag", 0));	
			cr.add(Restrictions.sqlRestriction(" extract(month from {alias}.uploaded_date) = ? ", month, StandardBasicTypes.INTEGER));
			cr.add(Restrictions.sqlRestriction(" extract(year from {alias}.uploaded_date) = ? ", year, StandardBasicTypes.INTEGER));		
			cr.setProjection(Projections.rowCount());
			Long count = (Long) cr.uniqueResult();
			return count;
		} catch (Exception e) {
			log.error(
					"dGetContentCountMonthly::CmLibraryProgramCourseDaoImpl::ContentManagement:: Plato Threw a BadException, full stack trace follows:",
					e);
			return null;
		}
	}

	@Override
	public Long dGetContentCountByCourseId(Long courseId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);
			cr.add(Restrictions.eq("deletedFlag", 0));	
			cr.add(Restrictions.eq("courseId", courseId));		
			cr.setProjection(Projections.rowCount());
			Long count = (Long) cr.uniqueResult();
			return count;
		} catch (Exception e) {
			log.error(
					"dGetContentCountByProgramId::CmLibraryProgramCourseDaoImpl::ContentManagement:: Plato Threw a BadException, full stack trace follows:",
					e);
			return null;
		}
	}

	@Override
	public Long dGetContentCountByCourseIdAndUploadedBy(Long courseId, Long uploadedBy) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryProgramCourse.class);
			cr.add(Restrictions.eq("deletedFlag", 0));	
			cr.add(Restrictions.eq("courseId", courseId));	
			cr.add(Restrictions.eq("uploadedBy", uploadedBy));	
			cr.setProjection(Projections.rowCount());
			Long count = (Long) cr.uniqueResult();
			return count;
		} catch (Exception e) {
			log.error(
					"dGetContentCountByCourseIdAndUploadedBy::CmLibraryProgramCourseDaoImpl::ContentManagement:: Plato Threw a BadException, full stack trace follows:",
					e);
			return null;
		}
	}
}