package com.srmri.plato.core.contentmanagement.daoImpl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.srmri.plato.core.contentmanagement.dao.CmLibraryCourseDao;
import com.srmri.plato.core.contentmanagement.entity.CmLibraryCourse;
import com.srmri.plato.core.contentmanagement.entity.CmLibraryProgramCourse;
import com.srmri.plato.core.contentmanagement.entity.EscapedRestrictions;

/**
 * Data access Services for interacting with digital library
 * course table
 */

@Repository("CmLibraryCourseDao")
public class CmLibraryCourseDaoImpl implements CmLibraryCourseDao
{
	
	@Autowired
	private SessionFactory sessionFactory;
		
	private final static Logger log = Logger.getLogger(CmLibraryCourseDaoImpl.class.getName());
	
	/**
	 * Add or update digital library course content details
	 * @param CmLibraryCourse libraryCourse
	 * @see Table cm_library_course
	 */
	@Override
	public void dAddLibraryCourseContent(CmLibraryCourse libraryCourse) 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		session.saveOrUpdate(libraryCourse);
		}catch(Exception e){
			log.error("dAddLibraryCourseContent::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
		}
		
	}

	/**
	 * get list of all digital library course 
	 * content details
	 * @return list of CmContentType objects
	 * @see Table cm_library_course
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CmLibraryCourse> dListAllLibraryCourseContents() 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		return (List<CmLibraryCourse>) session.createCriteria(CmLibraryCourse.class).list();
		}catch(Exception e){
			log.error("List::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
			return null;
		}
	
	}
	
	/**
	 * Delete digital library course content details
	 * @param CmLibraryCourse libraryCourse
	 * @see Table cm_library_course
	 */
	@Override
	public void dDeleteLibraryCourseContent(CmLibraryCourse libraryCourse) 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		session.createQuery("DELETE FROM CmLibraryCourse WHERE digitalLibraryCourseId = "+libraryCourse.getLibraryCourseId()).executeUpdate();
		}catch(Exception e){
			log.error("dDeleteLibrayCourseContent::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
		}
	}

	/**
	 * get  digital library course content details
	 * by library  course content id
	 * @param Long libraryCourseId
	 * @return CmLibraryCourse object
	 * @see Table cm_library_course
	 */
	@Override
	public CmLibraryCourse dGetLibraryCourseContent(long libraryCourseId) 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		return (CmLibraryCourse) session.get(CmLibraryCourse.class, libraryCourseId);
		}catch(Exception e){
			log.error("dGetLibraryCourseContent::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
			return null;
		}
	
	}

	/**
	 * get digital library course content details by
	 * year of publication
	 * @param String year of publication
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_course
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CmLibraryCourse> dGetContentByYearOfPublication(String yearPublication) 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		Criteria cr = session.createCriteria(CmLibraryCourse.class);
		
		cr.add(Restrictions.eq("yearPublication", yearPublication));
		
		return (List<CmLibraryCourse>) cr.list();
		}catch(Exception e){
			log.error("dGetContentByYearOfPublication::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
			return null;
		}
		
	}
	
	/**
	 * get digital library course content details by
	 * publisher
	 * @param String publisher
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_course
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CmLibraryCourse> dGetContentByPublisher(String publisher) 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		Criteria cr = session.createCriteria(CmLibraryCourse.class);
		
		cr.add(Restrictions.eq("publisher", publisher));
		
		return (List<CmLibraryCourse>) cr.list();
		}catch(Exception e){
			log.error("dGetContentByPublisher::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
			return null;
		}
	}
	
	/**
	 * get digital library course content details by
	 * author name
	 * @param String author name
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_course
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CmLibraryCourse> dGetContentByAuthorName(String author) 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		Criteria cr = session.createCriteria(CmLibraryCourse.class);
		
		cr.add(Restrictions.eq("author", author));
		
		return (List<CmLibraryCourse>) cr.list();
		}catch(Exception e){
			log.error("dGetContentByAuthorName::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
			return null;
		}
	}

	/**
	 * get digital library course content details by
	 * title
	 * @param String title
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_course
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CmLibraryCourse> dGetContentByTitle(String title) 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		Criteria cr = session.createCriteria(CmLibraryCourse.class);
		
		cr.add(Restrictions.eq("title", title));
		
		return (List<CmLibraryCourse>) cr.list();
		}catch(Exception e){
			log.error("dGetContentByTitle::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
			return null;
		}
	}

	/**
	 * get digital library course content details by
	 * uploadedBy
	 * @param Long uploadedBy
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_course
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CmLibraryCourse> dGetContentByUploadedBy(long uploadedBy) 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		Criteria cr = session.createCriteria(CmLibraryCourse.class);
		
		cr.add(Restrictions.eq("uploadedBy", uploadedBy));
		
		return (List<CmLibraryCourse>) cr.list();
		}catch(Exception e){
			log.error("dGetContentByUploadedBy::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
			return null;
		}
	}

	/**
	 * Soft Delete digital library course content details
	 * @param CmLibraryCourse libraryCourse
	 * @see Table cm_library_course
	 */
	@Override
	public void dSoftDeleteLibraryCourseContent(CmLibraryCourse libraryCourse) {
		try{
		Session session=sessionFactory.getCurrentSession();
		session.createQuery("UPDATE CmLibraryCourse SET deletedFlag=1 WHERE digitalLibraryCourseId = "+libraryCourse.getLibraryCourseId()).executeUpdate();
		}catch(Exception e){
			log.error("dsoftDeleteLibraryCourseContent::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
		}
		
	}

	/**
	 * Restore digital library course content details
	 * @param CmLibraryCourse libraryCourse
	 * @see Table cm_library_course
	 */
	@Override
	public void dRestoreLibraryCourseContent(CmLibraryCourse libraryCourse) {
		try{
		Session session=sessionFactory.getCurrentSession();
		session.createQuery("UPDATE CmLibraryCourse SET deletedFlag=0 WHERE digitalLibraryCourseId = "+libraryCourse.getLibraryCourseId()).executeUpdate();
		}catch(Exception e){
			log.error("dRestoreLibraryCourseContent::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
		}
		
	}

	/**
	 * get digital library course content details by
	 * course department map id
	 * @param Long course department map id
	 * @return list of CmLibraryCourse objects
	 * @see Table cm_library_course
	 */
	@Override
	public List<CmLibraryCourse> dGetContentByCourseDepartmentMapId(Long courseDepMapId) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			
			cr.add(Restrictions.eq("courseDepartmentMapId", courseDepMapId));
			
			return (List<CmLibraryCourse>) cr.list();
			}catch(Exception e){
				log.error("dGetContentByCourseDepartmentMapId::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
				return null;
			}
	}

	@Override
	public List<CmLibraryCourse> dGetContentByDeptId(Long departmentId) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			
			cr.add(Restrictions.eq("departmentId", departmentId));
			
			return (List<CmLibraryCourse>) cr.list();
			}catch(Exception e){
				log.error("dGetContentByDeptId::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
				return null;
			}
	}


	@Override
	public List<CmLibraryCourse> dGetContentByDeptIdCourseId(Long departmentId,
			Long courseId) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			
			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("courseId", courseId));
			return (List<CmLibraryCourse>) cr.list();
			}catch(Exception e){
				log.error("dGetContentByDeptIdCourseId::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
				return null;
			}
	}

	@Override
	public List<CmLibraryCourse> dGetContentByDeptIdCourseIdContentType(Long departmentId, Long courseId, Integer contentTypeId) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			
			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("courseId", courseId));
			cr.add(Restrictions.eq("contentTypeId", contentTypeId));
			
			return (List<CmLibraryCourse>) cr.list();
			}catch(Exception e){
				log.error("dGetContentByDeptIdCourseIdContentType::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
				return null;
			}
	}

	@Override
	public List<CmLibraryCourse> dGetContentByDeptIdAndContentType(Long departmentId, Integer contentTypeId) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			
			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("contentTypeId", contentTypeId));
			
			return (List<CmLibraryCourse>) cr.list();
			}catch(Exception e){
				log.error("dGetContentByDeptIdAndContentType::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
				return null;
			}
	}

	@Override
	public List<CmLibraryCourse> dGetContentByContentType(Integer contentType) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			
			cr.add(Restrictions.eq("contentTypeId", contentType));
			
			return (List<CmLibraryCourse>) cr.list();
			}catch(Exception e){
				log.error("dGetContentByContentType::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
				return null;
			}
	}
	
	@Override
	public List<CmLibraryCourse> dGetContentByCourseIdSort() {
		try{
		Session session = sessionFactory.getCurrentSession();
		Criteria crProgramCourses = session.createCriteria(CmLibraryCourse.class);	
		crProgramCourses.add(Restrictions.eq("deletedFlag", 0));
		
		crProgramCourses.setProjection(Projections.projectionList().add(Projections.groupProperty("courseId"), "courseId"));
		crProgramCourses.setResultTransformer(Transformers.aliasToBean(CmLibraryCourse.class));
		@SuppressWarnings("unchecked")
		List<CmLibraryCourse> courseList = crProgramCourses.list();
		return courseList;
		}catch(Exception e){
			log.error("dGetContentByCourseIdSort::CmLibraryCourseDaoImpl::ContentManagemnt::Plato Threw a BadException, full stack follows", e);
			return null;
		}
	}

	@Override
	public List<CmLibraryCourse> dGetContentByCourseId(Long courseId) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			
			cr.add(Restrictions.eq("courseId", courseId));
			
			return (List<CmLibraryCourse>) cr.list();
			}catch(Exception e){
				log.error("dGetContentByCourseId::CmLibraryProgramCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
				return null;
			}
	}

	@Override
	public List<CmLibraryCourse> dGetContentByContentTypeAndCourseId(Integer contentType, Long courseId) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			
			cr.add(Restrictions.eq("contentTypeId", contentType));
			cr.add(Restrictions.eq("courseId", courseId));
			
			return (List<CmLibraryCourse>) cr.list();
			}catch(Exception e){
				log.error("dGetContentByContentTypeAndCourseId::CmLibraryCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
				return null;
			}
	}

	@Override
	public List<CmLibraryCourse> dGetContentByDeptIdAndUploadedBy(Long departmentId, Long uploadedBy) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			
			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("uploadedBy", uploadedBy));
			
			return (List<CmLibraryCourse>) cr.list();
			}catch(Exception e){
				log.error("dGetContentByDeptIdAndUploadedBy::CmLibraryCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
				return null;
			}
	}

	@Override
	public List<CmLibraryCourse> dGetContentByDeptIdCourseIdUploadedBy(Long departmentId, Long courseId,
			Long uploadedBy) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			
			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("courseId", courseId));
			cr.add(Restrictions.eq("uploadedBy", uploadedBy));
			
			return (List<CmLibraryCourse>) cr.list();
			}catch(Exception e){
				log.error("dGetContentByDeptIdCourseIdUploadedBy::CmLibraryCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
				return null;
			}
	}

	@Override
	public List<CmLibraryCourse> dGetContentByDeptIdCourseIdContentTypeUploadedBy(Long departmentId, Long courseId,
			Integer contentTypeId, Long uploadedBy) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			
			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("courseId", courseId));
			cr.add(Restrictions.eq("contentTypeId", contentTypeId));
			cr.add(Restrictions.eq("uploadedBy", uploadedBy));
			
			return (List<CmLibraryCourse>) cr.list();
			}catch(Exception e){
				log.error("dGetContentByDeptIdCourseIdContentTypeUploadedBy::CmLibraryCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
				return null;
			}
	}

	@Override
	public List<CmLibraryCourse> dGetContentByDeptIdAndContentTypeUploadedBy(Long departmentId, Integer contentTypeId,
			Long uploadedBy) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			
			cr.add(Restrictions.eq("departmentId", departmentId));
			cr.add(Restrictions.eq("contentTypeId", contentTypeId));
			cr.add(Restrictions.eq("uploadedBy", uploadedBy));
			
			return (List<CmLibraryCourse>) cr.list();
			}catch(Exception e){
				log.error("dGetContentByDeptIdAndContentTypeUploadedBy::CmLibraryCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
				return null;
			}
	}

	@Override
	public List<CmLibraryCourse> dGetContentByContentTypeAndUploadedBy(Long contentType, Long uploadedBy) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			
			cr.add(Restrictions.eq("contentTypeId", contentType));
			cr.add(Restrictions.eq("uploadedBy", uploadedBy));
			
			return (List<CmLibraryCourse>) cr.list();
			}catch(Exception e){
				log.error("dGetContentByContentTypeAndUploadedBy::CmLibraryCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
				return null;
			}
	}

	@Override
	public List<CmLibraryCourse> dGetContentForAssigned(String title, Integer contentTypeId) {
		try{
			Session session=sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			
			cr.add(Restrictions.eq("title", title));
			cr.add(Restrictions.eq("contentTypeId", contentTypeId));
			cr.add(Restrictions.eq("deletedFlag", 0));
			
			return (List<CmLibraryCourse>) cr.list();
			}catch(Exception e){
				log.error("dGetContentForAssigned::CmLibraryCourseDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
				return null;
			}
	}

	

	

	@Override
	public CmLibraryCourse dGetDuplicateContentByTitle(String title) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria getContentByNameCriteria = session.createCriteria(CmLibraryCourse.class);

			getContentByNameCriteria.add(Restrictions.eq("title", title));
			return (CmLibraryCourse) getContentByNameCriteria.uniqueResult();

		} catch (Exception e) {
			log.error(
					"dGetDuplicateContentByTitle::CmLibraryProgramCourseDaoImpl::ContentManagement:: Plato Threw a BadException, full stack trace follows:",
					e);
			return null;
		}
	}

	

	@Override
	public CmLibraryCourse dGetDuplicateContentByFile(String fileUrl) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria getContentByNameCriteria = session.createCriteria(CmLibraryCourse.class);

			getContentByNameCriteria.add(EscapedRestrictions.ilike("fileUrl", fileUrl, MatchMode.EXACT));
			return (CmLibraryCourse) getContentByNameCriteria.uniqueResult();

		} catch (Exception e) {
			log.error(
					"dGetDuplicateContentByFile::CmLibraryProgramCourseDaoImpl::ContentManagement:: Plato Threw a BadException, full stack trace follows:",
					e);
			return null;
		}
	}

	@Override
	public Long dGetContentCountByMonth(int month, int year) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			cr.add(Restrictions.eq("deletedFlag", 0));	
			cr.add(Restrictions.sqlRestriction(" extract(month from {alias}.uploaded_date) = ? ", month, StandardBasicTypes.INTEGER));
			cr.add(Restrictions.sqlRestriction(" extract(year from {alias}.uploaded_date) = ? ", year, StandardBasicTypes.INTEGER));		
			cr.setProjection(Projections.rowCount());
			Long count = (Long) cr.uniqueResult();
			return count;
		} catch (Exception e) {
			log.error(
					"dGetContentCountMonthly::CmLibraryCourseDaoImpl::ContentManagement:: Plato Threw a BadException, full stack trace follows:",
					e);
			return null;
		}
	}

	@Override
	public Long dGetContentCountByCourseId(Long courseId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			cr.add(Restrictions.eq("deletedFlag", 0));	
			cr.add(Restrictions.eq("courseId", courseId));		
			cr.setProjection(Projections.rowCount());
			Long count = (Long) cr.uniqueResult();
			return count;
		} catch (Exception e) {
			log.error(
					"dGetContentCountByCourseId::CmLibraryCourseDaoImpl::ContentManagement:: Plato Threw a BadException, full stack trace follows:",
					e);
			return null;
		}
	}

	@Override
	public Long dGetContentCountByCourseIdAndUploadedBy(Long courseId, Long uploadedBy) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria cr = session.createCriteria(CmLibraryCourse.class);
			cr.add(Restrictions.eq("deletedFlag", 0));	
			cr.add(Restrictions.eq("courseId", courseId));	
			cr.add(Restrictions.eq("uploadedBy", uploadedBy));	
			cr.setProjection(Projections.rowCount());
			Long count = (Long) cr.uniqueResult();
			return count;
		} catch (Exception e) {
			log.error(
					"dGetContentCountByCourseIdAndUploadedBy::CmLibraryCourseDaoImpl::ContentManagement:: Plato Threw a BadException, full stack trace follows:",
					e);
			return null;
		}
	}

	
}
