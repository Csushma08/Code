package com.srmri.plato.core.contentmanagement.service;

import java.util.List;

import com.srmri.plato.core.contentmanagement.entity.CmLibraryProgramCourse;


public interface CmLibraryProgramCourseService 
{
	
	boolean blAddLibraryProgramCourseContent(CmLibraryProgramCourse libraryProgramCourse);

	List<CmLibraryProgramCourse> blListAllLibraryProgramCourseContents();
	
	CmLibraryProgramCourse blGetLibraryProgramCourseContent(long libraryProgramCourseId);
	
	boolean blDeleteLibraryProgramCourseContent(CmLibraryProgramCourse libraryProgramCourse);
	
	boolean blSoftDeleteLibraryProgramCourseContent(CmLibraryProgramCourse libraryProgramCourse);
	
	boolean blRestoreLibraryProgramCourseContent(CmLibraryProgramCourse libraryProgramCourse);
	
	List<CmLibraryProgramCourse> blGetContentByAuthorName(String authors);
	
	List<CmLibraryProgramCourse> blGetContentByPublisher(String publishers);
	
	List<CmLibraryProgramCourse> blGetContentByYearOfPublication(String yearofpublication);
	
	List<CmLibraryProgramCourse> blGetContentByUploadedBy(long uploadedBy);
	
	List<CmLibraryProgramCourse> blGetContentByTitle(String title);
	
	List<CmLibraryProgramCourse> blGetContentByProgramCourseMapId(Long programCourseMapId);

	List<CmLibraryProgramCourse> blGetContentByDeptId(Long departmentId);
	
	List<CmLibraryProgramCourse> blGetContentByDeptIdAndProgramId(Long departmentId, Long programId);
	
	List<CmLibraryProgramCourse> blGetContentByDeptIdProgramIdCourseId(Long departmentId, Long programId, Long courseId);
	
	List<CmLibraryProgramCourse> blGetContentByDeptIdProgramIdCourseIdContentType(Long departmentId, Long programId, Long courseId, Integer contentTypeId);
	
	List<CmLibraryProgramCourse> blGetContentByDeptIdAndContentType(Long departmentId, Integer contentTypeId);
	
	List<CmLibraryProgramCourse> blGetContentByDeptIdProgramIdContentType(Long departmentId, Long programId, Integer contentTypeId);
	
	List<CmLibraryProgramCourse> blGetContentByContentType(Integer contentType, Long programId);
	
	List<CmLibraryProgramCourse> blGetContentByContentTypeAndCourseId(Integer contentType, Long courseId);
	
	List<CmLibraryProgramCourse> blGetContentByCourseIdSort();
	
	List<CmLibraryProgramCourse> blGetContentByCourseId(Long courseId);
	
	List<CmLibraryProgramCourse> blGetContentByContentType(Integer contentType);
	
	List<CmLibraryProgramCourse> blGetContentByDeptIdAndUploadedBy(Long departmentId, Long uploadedBy);
	
	List<CmLibraryProgramCourse> blGetContentByDeptIdProgramIdUploadedBy(Long departmentId, Long programId, Long uploadedBy);
	
	List<CmLibraryProgramCourse> blGetContentByDeptIdProgramIdCourseIdUplodedBy(Long departmentId, Long programId, Long courseId, Long uploadedBy);
	
	List<CmLibraryProgramCourse> blGetContentByDeptIdProgramIdCourseIdContentTypeUploadedBy(Long departmentId, Long programId, Long courseId, Integer contentTypeId, Long uploadedBy);
	
	List<CmLibraryProgramCourse> blGetContentByDeptIdContentTypeUploadedBy(Long departmentId, Integer contentTypeId, Long uploadedBy);
	
	List<CmLibraryProgramCourse> blGetContentByDeptIdProgramIdContentTypeUploadedBy(Long departmentId, Long programId, Integer contentTypeId, Long uploadedBy);
	
	public Long blGetContentCount();
	
	public Long blGetContentCountByMonth(int month, int year);
	
	public Long blGetContentCountByCourseId(Long courseId);
	
	public Long blGetContentCountByCourseIdAndUploadedBy(Long courseId, Long uplodedBy);
	
	List<CmLibraryProgramCourse> blGetContentForAssigned(String title, Integer contentTypeId);
	
	CmLibraryProgramCourse blGetDuplicateContentByTitle(String title);
	
	CmLibraryProgramCourse blGetDuplicateContentByfile(String fileUrl);
	
}
