package com.srmri.plato.core.contentmanagement.test;


import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.srmri.plato.core.contentmanagement.service.*;


import com.srmri.plato.core.contentmanagement.entity.*;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		@SuppressWarnings("resource")
		ApplicationContext ctx = 
		        new ClassPathXmlApplicationContext("applicationCM.xml");
		CmLibraryProgramCourseService cmService = (CmLibraryProgramCourseService) ctx.getBean("CmLibraryProgramCourse");	
		/*int libraryProgramCourseId  = 100;
		CmLibraryProgramCourse cm = cmService.blGetLibraryProgramCourseContent(libraryProgramCourseId);*/
		/*System.out.println("Digital Library Program Course Id"+cm.getLibraryProgramCourseId());
		System.out.println("Program Course Map Id"+cm.getProgramCourseMapId());
		System.out.println("Content Title"+cm.getTitle());
		System.out.println("Content Author"+cm.getAuthor());
		System.out.println("Content "+cm.getFileUrl());
		System.out.println("Content Description"+cm.getDescription());
		System.out.println("Content Publisher"+cm.getPublishers());
		System.out.println("Content tags"+cm.getContentTags());
		System.out.println("Content Type"+cm.getContentTypeId());
		System.out.println("Content UploadedBy"+cm.getUploadedBy());
		System.out.println("Content UploadedDate"+cm.getUploadedDate());
		System.out.println("content Year of Publications"+cm.getYearPublication());
		System.out.println("Content Deleted Flag"+cm.getDeletedFlag());
		System.out.println("Content DeletedBy"+cm.getDeletedBy());
		System.out.println("Content Deleted Date"+cm.getDeletedDate());
		System.out.println("Content Download Count"+cm.getDownloadCount());
		System.out.println("Content Last Downloaded Date"+cm.getLastDownloadDate());*/
		int libraryProgramCourseId  = 126;
		CmLibraryProgramCourse cm = cmService.blGetLibraryProgramCourseContent(libraryProgramCourseId);
		//CmLibraryProgramCourse content = cmService.blGetDuplicateContentByTitleAndFile("English ebook sem1 material", "EnglishforEngineeringTeachersNote.pdf");
		System.out.println("size:"+cm.getTitle());
		
	}

}
