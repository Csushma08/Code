package com.srmri.plato.core.contentmanagement.serviceImpl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.srmri.plato.core.contentmanagement.dao.CmSystemInfoDao;

import com.srmri.plato.core.contentmanagement.entity.CmSystemInfo;

import com.srmri.plato.core.contentmanagement.service.CmSystemInfoService;

/**
 * Business logic Services for interacting with system 
 * info table
 */

@Service("CmSystemInfoService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class CmSystemInfoServiceImpl implements CmSystemInfoService
{
	
	@Autowired
	private CmSystemInfoDao systemInfoDao;
	
	private final static Logger log = Logger.getLogger(CmSystemInfoServiceImpl.class.getName());
	
	/**
	 * Add or update system info details
	 * @param CmSystenInfo object
	 * @see Table cm_systen_info
	 */
	@Transactional
	@Override
	public boolean blAddSystemInfo(CmSystemInfo systemInfo) 
	{
		try
		{
			systemInfoDao.dAddSystemInfo(systemInfo);
			return true;
		}
		catch(Exception e)
		{
			log.error("blAddSystemInfo::CmSystemInfoServiceImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
			return true;
		}
	}
	
	/**
	 * Get list of all system info
	 * @return list of CmSystemInfo objects
	 * @see Table cm_system_info
	 */
	@Override
	public List<CmSystemInfo> blListAllSystemInfos() 
	{
		return systemInfoDao.dListAllSystemInfos();
	}

	/**
	 * Get system info details by system info id
	 * @param Integer systemInfoId
	 * @return CmSystemInfo object
	 * @see Table cm_system_info
	 */
	public CmSystemInfo blGetSystemInfo(int systemInfoId) 
	{
		return systemInfoDao.dGetSystemInfo(systemInfoId);
	}
	
	/**
	 * Delete system info details
	 * @param CmSystemInfo object
	 * @return boolean true/false for success/failure 
	 * of deletion
	 * @see Table cm_system_info
	 */
	@Override
	public boolean blDeleteSystemInfo(CmSystemInfo systemInfo) 
	{
		try
		{
			systemInfoDao.dDeleteSystemInfo(systemInfo);
			return true;
		}
		catch(Exception e)
		{
			log.error("blDeleteSystemInfo::CmSystemInfoServiceImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
			return false;
		}
	}

	
	

}
