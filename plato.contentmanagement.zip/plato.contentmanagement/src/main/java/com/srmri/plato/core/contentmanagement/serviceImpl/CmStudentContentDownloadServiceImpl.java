package com.srmri.plato.core.contentmanagement.serviceImpl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.srmri.plato.core.contentmanagement.dao.CmStudentContentDownloadDao;
import com.srmri.plato.core.contentmanagement.entity.CmStudentContentDownload;
import com.srmri.plato.core.contentmanagement.service.CmStudentContentDownloadService;

/**
 * Business logic Services for interacting with student content download table
 */

@Service("CmStudentContentDownloadService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class CmStudentContentDownloadServiceImpl implements CmStudentContentDownloadService {

	@Autowired
	private CmStudentContentDownloadDao studentContentDownloadDao;

	private final static Logger log = Logger.getLogger(CmStudentContentDownloadServiceImpl.class.getName());

	/**
	 * Add or update student content download details
	 * @param CmStudentContentDownload object
	 * @return boolean true/false for success/failure of addition
	 * @see Table cm_student_content_download
	 */
	@Transactional
	@Override
	public boolean blAddStudentContentDownload(CmStudentContentDownload studentContentDownload) {
		try {
			studentContentDownloadDao.dAddStudentContentDownload(studentContentDownload);
			return true;
		} catch (Exception e) {
			log.error(
					"blAddStudentContentDownload::CmStudentContentDownloadServiceImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return false;
		}
	}

	/**
	 * get list of all student content download detail
	 * @return list of CmStudentContentDownload objects
	 * @see Table cm_student_content_download
	 */
	@Override
	public List<CmStudentContentDownload> blListAllStudentContentDownloads() {
		return studentContentDownloadDao.dListAllStudentContentDownloads();
	}

	/**
	 * get student content download details by studentcontentdownload id
	 * @param Long studentContentDownloadId
	 * @return CmStudentContentDownload object
	 * @see Table cm_student_content_download
	 */
	@Override
	public CmStudentContentDownload blGetStudentContentDownload(long studentContentDownloadId) {
		return studentContentDownloadDao.dGetStudentContentDownload(studentContentDownloadId);
	}

	/**
	 * delete student content download details
	 * @param CmStudentContentDownload object
	 * @return boolean true/false for success/failure of deletion
	 * @see Table cm_student_content_download
	 */
	@Override
	public boolean blDeleteStudentContentDownload(CmStudentContentDownload studentContentDownload) {
		try {
			studentContentDownloadDao.dDeleteStudentContentDownload(studentContentDownload);
			return true;
		} catch (Exception e) {
			log.error(
					"blDeleteStudentContentDownload::CmStudentContentDownloadServiceImpl::ContentManagement::Plato Threw a BadException, full stack follows",
					e);
			return false;
		}
	}

}
