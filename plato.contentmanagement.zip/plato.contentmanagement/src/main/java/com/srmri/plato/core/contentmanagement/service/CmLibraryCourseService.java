package com.srmri.plato.core.contentmanagement.service;

import java.util.List;

import com.srmri.plato.core.contentmanagement.entity.CmLibraryCourse;
import com.srmri.plato.core.contentmanagement.entity.CmLibraryProgramCourse;


public interface CmLibraryCourseService 
{
	
	boolean blAddLibraryCourseContent(CmLibraryCourse libraryCourse);

	List<CmLibraryCourse> blListAllLibraryCourseContents();
	
	CmLibraryCourse blGetLibraryCourseContent(long libraryCourseId);
	
	boolean blDeleteLibraryCourseContent(CmLibraryCourse libraryCourse);
	
	boolean blSoftDeleteLibraryCourseContent(CmLibraryCourse libraryCourse);
	
	boolean blRestoreLibraryCourseContent(CmLibraryCourse libraryCourse);
	
	List<CmLibraryCourse> blGetContentByAuthorName(String author);
	
	List<CmLibraryCourse> blGetContentByPublisher(String publisher);
	
	List<CmLibraryCourse> blGetContentByYearOfPublication(String yearPublication);
	
	List<CmLibraryCourse> blGetContentByTitle(String title);
	
	List<CmLibraryCourse> blGetContentByUploadedBy(long uploadedBy);
	
	List<CmLibraryCourse> blGetContentByCourseDepartmentMapId(Long courseDepMapId);
	
	List<CmLibraryCourse>  blGetContentByDeptId(Long departmentId);
	
	List<CmLibraryCourse> blGetContentByDeptIdCourseId(Long departmentId, Long courseId);
	
	List<CmLibraryCourse> blGetContentByDeptIdCourseIdContentType(Long departmentId, Long courseId, Integer contentTypeId);
	
	List<CmLibraryCourse> blGetContentByDeptIdAndContentType(Long departmentId, Integer contentTypeId);

	List<CmLibraryCourse> blGetContentByContentType(Integer contentType);
	
	List<CmLibraryCourse> blGetContentByContentTypeAndCourseId(Integer contentType, Long courseId);
	
	List<CmLibraryCourse> blGetContentByCourseIdSort();
	
	List<CmLibraryCourse> blGetContentByCourseId(Long courseId);
	
	List<CmLibraryCourse>  blGetContentByDeptIdAndUplaodedBy(Long departmentId, Long uploadedBy);
	
	List<CmLibraryCourse> blGetContentByDeptIdCourseIdUploadedBy(Long departmentId, Long courseId, Long uploadedBy);
	
	List<CmLibraryCourse> blGetContentByDeptIdCourseIdContentTypeUploadedBy(Long departmentId, Long courseId, Integer contentTypeId, Long uploadedBy);
	
	List<CmLibraryCourse> blGetContentByDeptIdAndContentTypeUploadedBy(Long departmentId, Integer contentTypeId, Long uploadedBy);

	List<CmLibraryCourse> blGetContentByContentTypeUploadedBy(Long contentType, Long uploadedBy);
	
	List<CmLibraryCourse> blGetContentForAssigned(String title, Integer contentTypeId);
	
	CmLibraryCourse blGetDuplicateContentByTitle(String title);
	
	CmLibraryCourse blGetDuplicateContentByfile(String fileUrl);
	
	public Long blGetContentCountByMonth(int month, int year);
	
	public Long blGetContentCountByCourseId(Long courseId);
	
	public Long blGetContentCountByCourseIdAndUplaodedBy(Long courseId, Long uploadedBy);

}
