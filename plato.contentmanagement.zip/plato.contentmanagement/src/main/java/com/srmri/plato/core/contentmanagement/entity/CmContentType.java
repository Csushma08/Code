package com.srmri.plato.core.contentmanagement.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Entity class for content type
 */

@Entity
@Table(name= "contentmanagement.cm_content_type")
public class CmContentType implements Serializable{

	private static final long serialVersionUID = 7812403651229318355L;

	@Id        
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator="role_level_seq")
	@SequenceGenerator(name="role_level_seq", sequenceName="contentmanagement.cm_content_type_content_type_id_seq", allocationSize=1)
	@Column(name = "content_type_id")
	private Integer contentTypeId;
	
	@Column(name="content_type_name")
	private String contentTypeName;
	
	/**
	 * Getter Method
	 * @return contentTypeId
	 */
	public Integer getContentTypeId() 
	{
		return contentTypeId;
	}

	/**
	 * Setter Method
	 * @param contentTypeId
	 */
	public void setContentTypeId(Integer contentTypeId) 
	{
		this.contentTypeId = contentTypeId;
	}

	/**
	 * Getter Method
	 * @return ContentTypeName
	 */
	public String getContentTypeName() 
	{
		return contentTypeName;
	}

	/**
	 * Setter Methods
	 * @param contentTypeName
	 */
	public void setContentTypeName(String contentTypeName) 
	{
		this.contentTypeName = contentTypeName;
	}

}
