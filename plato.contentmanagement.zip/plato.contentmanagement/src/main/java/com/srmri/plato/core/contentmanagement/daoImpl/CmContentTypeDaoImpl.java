package com.srmri.plato.core.contentmanagement.daoImpl;

/**
 * Data access Services for interacting with content type  
 * table
 */
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.srmri.plato.core.contentmanagement.dao.CmContentTypeDao;
import com.srmri.plato.core.contentmanagement.entity.CmContentType;


@Repository("CmContentTypeDao")
public class CmContentTypeDaoImpl implements CmContentTypeDao 
{
	private final static Logger log = Logger.getLogger(CmContentTypeDaoImpl.class.getName());
	@Autowired
	private SessionFactory sessionFactory;	
	
	/**
	 * get list of all the content types
	 * @return list of CmContentType objects
	 * @see Table cm_content_type
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<CmContentType> dListAllContentTypes() 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		return (List<CmContentType>) session.createCriteria(CmContentType.class).list();
		}catch(Exception e){
			log.error("list::CmContentTypeDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
			return null;
		}
	}
	
	/**
	 * Add or update content type details
	 * @param CmContentType contentType
	 * @see Table cm_content_type
	 */
	@Override
	public void dAddContentType(CmContentType contentType) 
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		session.saveOrUpdate(contentType);
		}catch(Exception e){
			log.error("list::CmContentTypeDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
		}
	
	}
	
	/**
	 * Delete content type details
	 * @param CmContentType contentType
	 * @see Table cm_content_type
	 */
	@Override
	public void dDeleteContentType(CmContentType contentType)
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		session.createQuery("DELETE FROM CmContentType WHERE contentTypeId = "+contentType.getContentTypeId()).executeUpdate();
		}catch(Exception e){
			log.error("list::CmContentTypeDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
		}
	}
	
	/**
	 * get content type details by contentTypeId
	 * @param Integer contentTypeId
	 * @return CmContentType object
	 * @see Table cm_content_type
	 */
	@Override
	public CmContentType dGetContentType(int contentTypeId)
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		return (CmContentType) session.get(CmContentType.class, contentTypeId);
		}catch(Exception e){
			log.error("list::CmContentTypeDaoImpl::ContentManagement::Plato Threw a BadException, full stack follows", e);
			return null;
		}
	}
	
}
