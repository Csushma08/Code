package com.srmri.plato.core.contentmanagement.service;

import java.util.List;

import com.srmri.plato.core.contentmanagement.entity.CmContentType;

public interface CmContentTypeService 
{	
	/**
	 * get content type details by contentTypeId
	 * @param contentTypeId
	 * @return CmContentType object
	 * @see Table cm_content_type
	 */
	CmContentType blGetContentType(int contentTypeId);
	
	/**
	 * Add or update library content type
	 * details
	 * @param CmContentType contentType
	 * @return boolean true/false for success/failure of 
	 * addition
	 * @see Table cm_content_type
	 */
	boolean blAddContentType(CmContentType contentType);
	
	/**
	 * Delete content type details
	 * @param CmContentType contentType
	 * @return boolean true/false for success/failure of
	 * deletion
	 * @see Table cm_content_type
	 */
	boolean blDeleteContentType(CmContentType contentType);
	
	/**
	 * get list of all content type details
	 * @return list of CmContentType objects
	 * @see Table cm_content_type
	 */
	List<CmContentType> blListAllContentTypes();
	
}
